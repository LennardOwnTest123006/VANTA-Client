package dev.vanta.client.bridge;

import dev.vanta.core.bridge.KeyRef;
import dev.vanta.core.bridge.KeyType;
import java.util.Optional;
import net.minecraft.class_2960;
import net.minecraft.class_3675;

/**
 * Conversions between the core's Minecraft-free {@link KeyRef} and {@link class_3675.class_306}, plus the mapping of
 * key-mapping categories to the {@code key.categories.*} ids the core groups by.
 */
public final class KeyConversions {
    private KeyConversions() {
    }

    /** The vanilla namespace. */
    private static final String MINECRAFT = "minecraft";

    /** Converts a core key reference to the game's key; unbound references become {@link class_3675#field_16237}. */
    public static class_3675.class_306 toKey(KeyRef ref) {
        if (ref == null || ref.isUnbound()) {
            return class_3675.field_16237;
        }
        return toType(ref.type()).method_1447(ref.code());
    }

    /** Converts a game key to a core key reference ({@code UNKNOWN} maps to an unbound reference). */
    public static KeyRef toRef(class_3675.class_306 key) {
        if (key == null) {
            return KeyRef.UNBOUND;
        }
        return new KeyRef(toType(key.method_1442()), key.method_1444(), key.method_1441());
    }

    /** {@link KeyType} to {@link class_3675.class_307}; the two enums share constant names. */
    public static class_3675.class_307 toType(KeyType type) {
        return switch (type) {
            case KEYSYM -> class_3675.class_307.field_1668;
            case SCANCODE -> class_3675.class_307.field_1671;
            case MOUSE -> class_3675.class_307.field_1672;
        };
    }

    /** {@link class_3675.class_307} to {@link KeyType}. */
    public static KeyType toType(class_3675.class_307 type) {
        if (type == class_3675.class_307.field_1672) {
            return KeyType.MOUSE;
        }
        if (type == class_3675.class_307.field_1671) {
            return KeyType.SCANCODE;
        }
        return KeyType.KEYSYM;
    }

    /**
     * Parses a vanilla key name such as {@code key.keyboard.c} or {@code key.mouse.left}; unknown names yield empty.
     */
    public static Optional<class_3675.class_306> fromVanillaName(String name) {
        if (name == null || name.isBlank()) {
            return Optional.empty();
        }
        try {
            return Optional.of(class_3675.method_15981(name));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
    }

    /**
     * Category id in the core's convention: vanilla {@code minecraft:movement} becomes
     * {@code key.categories.movement}, VANTA's {@code vanta:vanta} becomes {@code key.categories.vanta} and another
     * mod's {@code modid:thing} becomes {@code key.categories.modid.thing}.
     */
    public static String categoryId(class_2960 id) {
        String namespace = id.method_12836();
        String path = id.method_12832();
        if (MINECRAFT.equals(namespace) || namespace.equals(path)) {
            return "key.categories." + path;
        }
        return "key.categories." + namespace + "." + path;
    }

    /** True for categories registered by the game itself. */
    public static boolean isVanillaCategory(class_2960 id) {
        return MINECRAFT.equals(id.method_12836());
    }
}
