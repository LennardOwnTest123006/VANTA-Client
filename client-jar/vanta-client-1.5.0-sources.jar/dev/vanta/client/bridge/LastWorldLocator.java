package dev.vanta.client.bridge;

import dev.vanta.client.VantaClient;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_310;
import net.minecraft.class_32;
import net.minecraft.class_34;
import net.minecraft.class_442;
import net.minecraft.class_526;

/**
 * Finds the most recently played singleplayer world for the main menu's "Continue" button.
 * <p>
 * Level summaries are read from disk asynchronously (exactly like the vanilla world list) and cached for a few
 * seconds, so the main menu never blocks the render thread while it polls {@link #lastWorldName()} every frame.
 */
public final class LastWorldLocator {
    /** How long a cached answer is reused before the saves folder is scanned again. */
    static final long REFRESH_INTERVAL_MS = 3000L;

    /**
     * The chosen world.
     *
     * @param levelId    folder name used by {@code WorldOpenFlows.openWorld}
     * @param name       display name
     * @param lastPlayed epoch millis
     */
    record LastWorld(String levelId, String name, long lastPlayed) {
    }

    private volatile Optional<LastWorld> latest = Optional.empty();
    private volatile long refreshedAt;
    private volatile boolean loading;

    /** Display name of the most recently played world, if the saves folder has one. */
    public Optional<String> lastWorldName() {
        refreshIfStale();
        return latest.map(LastWorld::name);
    }

    /**
     * Opens the most recently played world.
     *
     * @return false when no world is known yet (the caller should open the world list instead)
     */
    public boolean continueLastWorld() {
        refreshIfStale();
        Optional<LastWorld> world = latest;
        if (world.isEmpty()) {
            return false;
        }
        class_310 minecraft = class_310.method_1551();
        minecraft.method_41735().method_57784(world.get().levelId(),
                () -> minecraft.method_1507(new class_526(new class_442())));
        return true;
    }

    private void refreshIfStale() {
        long now = System.currentTimeMillis();
        if (loading || now - refreshedAt < REFRESH_INTERVAL_MS) {
            return;
        }
        loading = true;
        try {
            class_32 source = class_310.method_1551().method_1586();
            class_32.class_7410 candidates = source.method_235();
            source.method_43417(candidates).whenComplete((summaries, error) -> {
                if (error != null) {
                    VantaClient.LOGGER.debug("Could not read level summaries", error);
                } else {
                    latest = pickLatest(summaries);
                }
                refreshedAt = System.currentTimeMillis();
                loading = false;
            });
        } catch (RuntimeException e) {
            VantaClient.LOGGER.debug("Could not list level candidates", e);
            latest = Optional.empty();
            refreshedAt = now;
            loading = false;
        }
    }

    /** The playable world with the newest {@code lastPlayed} stamp. */
    static Optional<LastWorld> pickLatest(List<class_34> summaries) {
        LastWorld best = null;
        for (class_34 summary : summaries) {
            if (summary.method_27021() || summary.method_33784() || summary.method_255()) {
                continue;
            }
            if (best == null || summary.method_249() > best.lastPlayed()) {
                best = new LastWorld(summary.method_248(), summary.method_252(), summary.method_249());
            }
        }
        return Optional.ofNullable(best);
    }
}
