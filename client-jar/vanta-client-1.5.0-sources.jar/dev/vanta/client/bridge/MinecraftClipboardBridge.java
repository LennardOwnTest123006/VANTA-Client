package dev.vanta.client.bridge;

import dev.vanta.core.bridge.ClipboardBridge;
import net.minecraft.class_310;

/**
 * {@link ClipboardBridge} over the game's GLFW clipboard access ({@code KeyboardHandler}).
 */
public final class MinecraftClipboardBridge implements ClipboardBridge {
    @Override
    public String get() {
        class_310 minecraft = class_310.method_1551();
        if (minecraft == null || minecraft.field_1774 == null) {
            return "";
        }
        String text = minecraft.field_1774.method_1460();
        return text == null ? "" : text;
    }

    @Override
    public void set(String text) {
        class_310 minecraft = class_310.method_1551();
        if (minecraft != null && minecraft.field_1774 != null) {
            minecraft.field_1774.method_1455(text == null ? "" : text);
        }
    }
}
