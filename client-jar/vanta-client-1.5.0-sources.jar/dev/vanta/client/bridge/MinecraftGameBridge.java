package dev.vanta.client.bridge;

import dev.vanta.client.screen.VanillaScreenOpener;
import dev.vanta.core.VantaVersion;
import dev.vanta.core.bridge.EffectInfo;
import dev.vanta.core.bridge.GameBridge;
import dev.vanta.core.bridge.ItemInfo;
import dev.vanta.core.bridge.KeyStates;
import dev.vanta.core.bridge.VanillaScreen;
import dev.vanta.core.bridge.Vec3d;
import dev.vanta.core.perf.CpuSampler;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1109;
import net.minecraft.class_1132;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_3417;
import net.minecraft.class_5218;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_640;
import net.minecraft.class_642;
import net.minecraft.class_746;
import org.lwjgl.opengl.GL11;

/**
 * {@link GameBridge} on top of {@link class_310}. Every method reads the live game state through the public
 * Minecraft API; nothing here writes to the world or sends packets. All methods are safe to call on the title
 * screen (they return empty values when no world is loaded).
 */
public final class MinecraftGameBridge implements GameBridge {
    private final CpuSampler cpu = new CpuSampler();
    private final LastWorldLocator lastWorld = new LastWorldLocator();
    private final String fabricLoaderVersion;
    /** {@code GL_RENDERER}, read once at CLIENT_STARTED by {@link #captureGpuRenderer()}. */
    private volatile String gpuRenderer;

    public MinecraftGameBridge() {
        this.fabricLoaderVersion = FabricLoader.getInstance().getModContainer("fabricloader")
                .map(c -> c.getMetadata().getVersion().getFriendlyString())
                .orElse(VantaVersion.FABRIC_LOADER);
    }

    private static class_310 minecraft() {
        return class_310.method_1551();
    }

    private static class_746 player() {
        class_310 minecraft = minecraft();
        return minecraft == null ? null : minecraft.field_1724;
    }

    private static class_638 level() {
        class_310 minecraft = minecraft();
        return minecraft == null ? null : minecraft.field_1687;
    }

    // ---- performance -------------------------------------------------------------------------------------------

    @Override
    public int fps() {
        class_310 minecraft = minecraft();
        return minecraft == null ? 0 : minecraft.method_47599();
    }

    /** Duration of the last frame as measured by the game loop ({@code Minecraft.getFrameTimeNs}). */
    @Override
    public double frameTimeMillis() {
        class_310 minecraft = minecraft();
        return minecraft == null ? 0.0 : minecraft.method_47600() / 1_000_000.0;
    }

    @Override
    public long memoryUsedBytes() {
        Runtime runtime = Runtime.getRuntime();
        return runtime.totalMemory() - runtime.freeMemory();
    }

    @Override
    public long memoryAllocatedBytes() {
        return Runtime.getRuntime().totalMemory();
    }

    @Override
    public long memoryMaxBytes() {
        return Runtime.getRuntime().maxMemory();
    }

    @Override
    public OptionalDouble cpuLoad() {
        return cpu.sample();
    }

    // ---- world -------------------------------------------------------------------------------------------------

    @Override
    public boolean isInWorld() {
        return level() != null && player() != null;
    }

    /**
     * Smart Boost's gameplay gate: a world is loaded, no screen is open (pause menu, inventory, chat, VANTA screens),
     * the game is not paused and the window has the input focus.
     */
    @Override
    public boolean isGameplayActive() {
        class_310 minecraft = minecraft();
        return minecraft != null && minecraft.field_1687 != null && minecraft.field_1724 != null && minecraft.field_1755 == null
                && !minecraft.method_1493() && minecraft.method_1569();
    }

    @Override
    public Optional<String> gpuRenderer() {
        return Optional.ofNullable(gpuRenderer);
    }

    /**
     * Reads the OpenGL renderer string once (call on the render thread with the GL context current, i.e. at
     * CLIENT_STARTED). Any failure leaves it unknown; Smart Boost then starts from its unknown-GPU guess.
     */
    public void captureGpuRenderer() {
        if (gpuRenderer != null) {
            return;
        }
        try {
            String renderer = GL11.glGetString(GL11.GL_RENDERER);
            if (renderer != null && !renderer.isBlank()) {
                gpuRenderer = renderer.trim();
            }
        } catch (RuntimeException | LinkageError e) {
            // No current context or no OpenGL binding: the renderer string is optional.
        }
    }

    @Override
    public Optional<Vec3d> playerPosition() {
        class_746 player = player();
        if (player == null) {
            return Optional.empty();
        }
        class_243 position = player.method_73189();
        return Optional.of(new Vec3d(position.field_1352, position.field_1351, position.field_1350));
    }

    @Override
    public float yaw() {
        class_746 player = player();
        return player == null ? 0f : player.method_36454();
    }

    @Override
    public float pitch() {
        class_746 player = player();
        return player == null ? 0f : player.method_36455();
    }

    @Override
    public Optional<String> biomeId() {
        class_746 player = player();
        class_638 level = level();
        if (player == null || level == null) {
            return Optional.empty();
        }
        return level.method_23753(player.method_24515()).method_40230().map(key -> key.method_29177().toString());
    }

    @Override
    public Optional<String> dimensionId() {
        class_638 level = level();
        if (level == null) {
            return Optional.empty();
        }
        return Optional.of(level.method_27983().method_29177().toString());
    }

    @Override
    public Optional<String> serverAddress() {
        class_310 minecraft = minecraft();
        if (minecraft == null || minecraft.method_1542() || level() == null) {
            return Optional.empty();
        }
        class_642 server = minecraft.method_1558();
        if (server == null || server.field_3761 == null || server.field_3761.isBlank()) {
            return Optional.empty();
        }
        return Optional.of(server.field_3761);
    }

    @Override
    public Optional<String> serverName() {
        class_310 minecraft = minecraft();
        if (minecraft == null || minecraft.method_1542() || level() == null) {
            return Optional.empty();
        }
        class_642 server = minecraft.method_1558();
        if (server == null || server.field_3752 == null || server.field_3752.isBlank()) {
            return Optional.empty();
        }
        return Optional.of(server.field_3752);
    }

    @Override
    public boolean isSingleplayer() {
        class_310 minecraft = minecraft();
        return minecraft != null && level() != null && minecraft.method_1542();
    }

    /**
     * Folder name of the open singleplayer level: the integrated server's world directory
     * ({@code MinecraftServer.getWorldPath(LevelResource.ROOT)}, the folder under {@code saves/}). This is the name
     * {@code WorldKeys.singleplayer} keys waypoints by, not the display name from {@code level.dat}.
     */
    @Override
    public Optional<String> singleplayerLevelName() {
        class_310 minecraft = minecraft();
        if (minecraft == null || level() == null || !minecraft.method_1542()) {
            return Optional.empty();
        }
        class_1132 server = minecraft.method_1576();
        if (server == null) {
            return Optional.empty();
        }
        try {
            Path root = server.method_27050(class_5218.field_24188).toAbsolutePath().normalize();
            Path name = root.getFileName();
            if (name == null || name.toString().isBlank()) {
                return Optional.empty();
            }
            return Optional.of(name.toString());
        } catch (RuntimeException e) {
            return Optional.empty();
        }
    }

    @Override
    public OptionalInt pingMillis() {
        class_310 minecraft = minecraft();
        class_746 player = player();
        if (minecraft == null || player == null) {
            return OptionalInt.empty();
        }
        class_634 connection = minecraft.method_1562();
        if (connection == null) {
            return OptionalInt.empty();
        }
        class_640 info = connection.method_2871(player.method_5667());
        return info == null ? OptionalInt.empty() : OptionalInt.of(Math.max(0, info.method_2959()));
    }

    @Override
    public int armorValue() {
        class_746 player = player();
        return player == null ? 0 : player.method_6096();
    }

    @Override
    public List<ItemInfo> armorPieces() {
        class_746 player = player();
        if (player == null) {
            return List.of(ItemInfo.EMPTY, ItemInfo.EMPTY, ItemInfo.EMPTY, ItemInfo.EMPTY);
        }
        List<ItemInfo> out = new ArrayList<>(4);
        out.add(itemInfo(player.method_6118(class_1304.field_6169)));
        out.add(itemInfo(player.method_6118(class_1304.field_6174)));
        out.add(itemInfo(player.method_6118(class_1304.field_6172)));
        out.add(itemInfo(player.method_6118(class_1304.field_6166)));
        return out;
    }

    @Override
    public List<ItemInfo> heldItems() {
        class_746 player = player();
        if (player == null) {
            return List.of(ItemInfo.EMPTY, ItemInfo.EMPTY);
        }
        return List.of(itemInfo(player.method_6047()), itemInfo(player.method_6079()));
    }

    /** Converts a stack to the core's snapshot; empty stacks map to {@link ItemInfo#EMPTY}. */
    static ItemInfo itemInfo(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return ItemInfo.EMPTY;
        }
        String name = stack.method_7964().getString();
        if (!stack.method_7963()) {
            return new ItemInfo(name, 0, 0);
        }
        int max = stack.method_7936();
        return new ItemInfo(name, Math.max(0, max - stack.method_7919()), max);
    }

    @Override
    public List<EffectInfo> activeEffects() {
        class_746 player = player();
        if (player == null) {
            return List.of();
        }
        List<EffectInfo> out = new ArrayList<>();
        for (class_1293 instance : player.method_6026()) {
            if (!instance.method_5581()) {
                continue;
            }
            class_1291 effect = instance.method_5579().comp_349();
            out.add(new EffectInfo(effect.method_5560().getString(), effect.method_5556(), instance.method_5584(),
                    instance.method_5578(), instance.method_48559()));
        }
        return out;
    }

    @Override
    public KeyStates keyStates() {
        class_310 minecraft = minecraft();
        if (minecraft == null || minecraft.field_1690 == null || player() == null) {
            return KeyStates.NONE;
        }
        class_315 options = minecraft.field_1690;
        return new KeyStates(options.field_1894.method_1434(), options.field_1913.method_1434(), options.field_1881.method_1434(),
                options.field_1849.method_1434(), options.field_1903.method_1434(), options.field_1832.method_1434(),
                options.field_1886.method_1434(), options.field_1904.method_1434());
    }

    @Override
    public int entityCount() {
        class_638 level = level();
        return level == null ? 0 : level.method_18120();
    }

    @Override
    public int renderDistance() {
        class_310 minecraft = minecraft();
        return minecraft == null || minecraft.field_1690 == null ? 0 : minecraft.field_1690.method_42503().method_41753();
    }

    @Override
    public int simulationDistance() {
        class_310 minecraft = minecraft();
        return minecraft == null || minecraft.field_1690 == null ? 0 : minecraft.field_1690.method_42510().method_41753();
    }

    // ---- versions & time ---------------------------------------------------------------------------------------

    @Override
    public String minecraftVersion() {
        return VantaVersion.MINECRAFT;
    }

    @Override
    public String fabricLoaderVersion() {
        return fabricLoaderVersion;
    }

    @Override
    public String clientVersion() {
        return FabricLoader.getInstance().getModContainer("vanta")
                .map(c -> c.getMetadata().getVersion().getFriendlyString())
                .orElse(VantaVersion.CLIENT);
    }

    @Override
    public long currentTimeMillis() {
        return System.currentTimeMillis();
    }

    @Override
    public long gameTicks() {
        class_638 level = level();
        return level == null ? 0L : level.method_75260();
    }

    // ---- actions -----------------------------------------------------------------------------------------------

    @Override
    public void openVanillaScreen(VanillaScreen screen) {
        VanillaScreenOpener.open(screen);
    }

    @Override
    public boolean continueLastWorld() {
        return lastWorld.continueLastWorld();
    }

    @Override
    public Optional<String> lastWorldName() {
        return lastWorld.lastWorldName();
    }

    @Override
    public void quitGame() {
        minecraft().method_1592();
    }

    @Override
    public void openUrl(String url) {
        VanillaScreenOpener.openUrl(url);
    }

    @Override
    public void playUiSound() {
        class_310 minecraft = minecraft();
        if (minecraft != null) {
            minecraft.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
        }
    }

    @Override
    public Optional<Path> screenshotsDir() {
        class_310 minecraft = minecraft();
        if (minecraft == null) {
            return Optional.empty();
        }
        Path dir = new File(minecraft.field_1697, "screenshots").toPath();
        return Files.isDirectory(dir) ? Optional.of(dir) : Optional.empty();
    }

    @Override
    public boolean isDevelopment() {
        return FabricLoader.getInstance().isDevelopmentEnvironment();
    }
}
