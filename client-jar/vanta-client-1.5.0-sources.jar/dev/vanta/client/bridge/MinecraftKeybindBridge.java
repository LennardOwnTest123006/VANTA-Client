package dev.vanta.client.bridge;

import dev.vanta.core.bridge.KeyBinding;
import dev.vanta.core.bridge.KeyRef;
import dev.vanta.core.bridge.KeybindBridge;
import dev.vanta.core.i18n.Lang;
import dev.vanta.core.keybinds.VantaKeys;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;

/**
 * {@link KeybindBridge} over {@code Options.keyMappings}: every mapping the vanilla Controls screen shows (vanilla,
 * VANTA and other mods). Rebinding goes through {@link class_304#method_1422} followed by {@link class_304#method_1426()}
 * and {@code options.save()}, which is exactly what the vanilla screen does.
 */
public final class MinecraftKeybindBridge implements KeybindBridge {

    private static class_315 options() {
        class_310 minecraft = class_310.method_1551();
        return minecraft == null ? null : minecraft.field_1690;
    }

    @Override
    public List<KeyBinding> all() {
        class_315 options = options();
        if (options == null || options.field_1839 == null) {
            return List.of();
        }
        List<KeyBinding> out = new ArrayList<>(options.field_1839.length);
        for (class_304 mapping : options.field_1839) {
            out.add(toBinding(mapping));
        }
        return out;
    }

    /**
     * Snapshot of one mapping in the core's representation. VANTA's own category is labelled from the VANTA bundle;
     * every other category uses the game's label so other mods' categories read exactly as in the Controls screen.
     */
    static KeyBinding toBinding(class_304 mapping) {
        class_304.class_11900 category = mapping.method_1423();
        String categoryId = KeyConversions.categoryId(category.comp_4879());
        String categoryName = VantaKeys.CATEGORY.equals(categoryId) ? Lang.tr(VantaKeys.CATEGORY)
                : category.method_74697().getString();
        KeyRef bound = KeyConversions.toRef(KeyBindingHelper.getBoundKeyOf(mapping));
        return new KeyBinding(mapping.method_1431(), class_2561.method_43471(mapping.method_1431()).getString(), categoryId,
                categoryName, bound.name(), bound.code(), bound.type(), mapping.method_1427(),
                KeyConversions.isVanillaCategory(category.comp_4879()));
    }

    /** The live mapping with this name, if registered. */
    private static Optional<class_304> mapping(String id) {
        class_315 options = options();
        if (options == null || options.field_1839 == null || id == null) {
            return Optional.empty();
        }
        for (class_304 mapping : options.field_1839) {
            if (mapping.method_1431().equals(id)) {
                return Optional.of(mapping);
            }
        }
        return Optional.empty();
    }

    @Override
    public boolean setKey(String id, KeyRef key) {
        Optional<class_304> mapping = mapping(id);
        if (mapping.isEmpty()) {
            return false;
        }
        mapping.get().method_1422(KeyConversions.toKey(key));
        commit();
        return true;
    }

    @Override
    public boolean reset(String id) {
        Optional<class_304> mapping = mapping(id);
        if (mapping.isEmpty()) {
            return false;
        }
        mapping.get().method_1422(mapping.get().method_1429());
        commit();
        return true;
    }

    @Override
    public void resetAll() {
        class_315 options = options();
        if (options == null || options.field_1839 == null) {
            return;
        }
        for (class_304 mapping : options.field_1839) {
            mapping.method_1422(mapping.method_1429());
        }
        commit();
    }

    /** Rebuilds the key → mapping lookup table and persists {@code options.txt}. */
    private static void commit() {
        class_304.method_1426();
        class_315 options = options();
        if (options != null) {
            options.method_1640();
        }
    }
}
