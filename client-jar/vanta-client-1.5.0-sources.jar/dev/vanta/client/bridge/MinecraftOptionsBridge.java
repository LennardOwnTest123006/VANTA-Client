package dev.vanta.client.bridge;

import dev.vanta.core.bridge.OptionsBridge;
import dev.vanta.core.bridge.VanillaOption;
import java.util.EnumMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_3419;
import net.minecraft.class_4063;
import net.minecraft.class_4066;
import net.minecraft.class_5365;
import net.minecraft.class_7172;
import net.minecraft.class_9927;

/**
 * {@link OptionsBridge} on top of {@link class_315}. Every {@link VanillaOption} maps to the matching
 * {@link class_7172}; writing through {@code OptionInstance.set} runs the game's own side effects (a render
 * distance change reloads chunks, vsync toggles the window, …), so changing an option here is identical to moving the
 * slider in Video Settings.
 * <p>
 * The map is built lazily on first use because {@link class_315} does not exist yet while mods initialise.
 */
public final class MinecraftOptionsBridge implements OptionsBridge {

    /** Read/write access to one option with values in the bridge's exchange types. */
    private record Access(Supplier<Object> getter, Predicate<Object> setter) {
    }

    private Map<VanillaOption, Access> accessors;

    private static class_315 options() {
        class_310 minecraft = class_310.method_1551();
        return minecraft == null ? null : minecraft.field_1690;
    }

    private Map<VanillaOption, Access> accessors() {
        if (accessors == null) {
            class_315 options = options();
            if (options == null) {
                return Map.of();
            }
            accessors = build(options);
        }
        return accessors;
    }

    private static Map<VanillaOption, Access> build(class_315 o) {
        Map<VanillaOption, Access> map = new EnumMap<>(VanillaOption.class);
        // video
        map.put(VanillaOption.FRAMERATE_LIMIT, number(o.method_42524(), Number::intValue));
        map.put(VanillaOption.RENDER_DISTANCE, number(o.method_42503(), Number::intValue));
        map.put(VanillaOption.SIMULATION_DISTANCE, number(o.method_42510(), Number::intValue));
        map.put(VanillaOption.PARTICLES, enumeration(o.method_42475(), class_4066.class));
        map.put(VanillaOption.CLOUDS, enumeration(o.method_42528(), class_4063.class));
        map.put(VanillaOption.SMOOTH_LIGHTING, bool(o.method_41792()));
        map.put(VanillaOption.ENTITY_SHADOWS, bool(o.method_42435()));
        map.put(VanillaOption.ENTITY_DISTANCE_SCALING, number(o.method_42517(), Number::doubleValue));
        map.put(VanillaOption.VSYNC, bool(o.method_42433()));
        map.put(VanillaOption.GUI_SCALE, number(o.method_42474(), Number::intValue));
        map.put(VanillaOption.BIOME_BLEND, number(o.method_41805(), Number::intValue));
        map.put(VanillaOption.MIPMAP_LEVELS, number(o.method_42563(), Number::intValue));
        map.put(VanillaOption.VIEW_BOBBING, bool(o.method_42448()));
        map.put(VanillaOption.FOV, number(o.method_41808(), Number::intValue));
        map.put(VanillaOption.MENU_BLUR, number(o.method_57702(), Number::intValue));
        map.put(VanillaOption.GRAPHICS_MODE, graphicsPreset(o));
        map.put(VanillaOption.INACTIVITY_FPS_LIMIT, enumeration(o.method_61970(), class_9927.class));
        map.put(VanillaOption.SCREEN_EFFECT_SCALE, number(o.method_42453(), Number::doubleValue));
        map.put(VanillaOption.FOV_EFFECT_SCALE, number(o.method_42454(), Number::doubleValue));
        map.put(VanillaOption.GLINT_SPEED, number(o.method_48580(), Number::doubleValue));
        map.put(VanillaOption.GLINT_STRENGTH, number(o.method_48581(), Number::doubleValue));
        map.put(VanillaOption.AUTOSAVE_INDICATOR, bool(o.method_42452()));
        map.put(VanillaOption.PANORAMA_SPEED, number(o.method_45581(), Number::doubleValue));
        map.put(VanillaOption.DARK_LOADING_SCREEN, bool(o.method_41772()));
        // audio
        map.put(VanillaOption.MASTER_VOLUME, volume(o, class_3419.field_15250));
        map.put(VanillaOption.MUSIC_VOLUME, volume(o, class_3419.field_15253));
        map.put(VanillaOption.RECORDS_VOLUME, volume(o, class_3419.field_15247));
        map.put(VanillaOption.WEATHER_VOLUME, volume(o, class_3419.field_15252));
        map.put(VanillaOption.BLOCKS_VOLUME, volume(o, class_3419.field_15245));
        map.put(VanillaOption.HOSTILE_VOLUME, volume(o, class_3419.field_15251));
        map.put(VanillaOption.NEUTRAL_VOLUME, volume(o, class_3419.field_15254));
        map.put(VanillaOption.PLAYERS_VOLUME, volume(o, class_3419.field_15248));
        map.put(VanillaOption.AMBIENT_VOLUME, volume(o, class_3419.field_15256));
        map.put(VanillaOption.VOICE_VOLUME, volume(o, class_3419.field_15246));
        map.put(VanillaOption.SHOW_SUBTITLES, bool(o.method_42443()));
        // controls
        map.put(VanillaOption.MOUSE_SENSITIVITY, number(o.method_42495(), Number::doubleValue));
        map.put(VanillaOption.INVERT_MOUSE, bool(o.method_42438()));
        map.put(VanillaOption.MOUSE_WHEEL_SENSITIVITY, number(o.method_41806(), Number::doubleValue));
        map.put(VanillaOption.DISCRETE_SCROLL, bool(o.method_42439()));
        map.put(VanillaOption.RAW_MOUSE_INPUT, bool(o.method_41807()));
        map.put(VanillaOption.AUTO_JUMP, bool(o.method_42423()));
        map.put(VanillaOption.TOGGLE_SNEAK, bool(o.method_42449()));
        map.put(VanillaOption.TOGGLE_SPRINT, bool(o.method_42450()));
        // accessibility
        map.put(VanillaOption.HIGH_CONTRAST, bool(o.method_49600()));
        map.put(VanillaOption.REDUCED_DEBUG_INFO, bool(o.method_42442()));
        map.put(VanillaOption.TEXT_BACKGROUND_OPACITY, number(o.method_42550(), Number::doubleValue));
        map.put(VanillaOption.CHAT_OPACITY, number(o.method_42542(), Number::doubleValue));
        return map;
    }

    // ---- accessor factories ------------------------------------------------------------------------------------

    private static <T extends Number> Access number(class_7172<T> instance, Function<Number, T> convert) {
        return new Access(instance::method_41753, value -> {
            if (!(value instanceof Number number)) {
                return false;
            }
            instance.method_41748(convert.apply(number));
            return true;
        });
    }

    private static Access bool(class_7172<Boolean> instance) {
        return new Access(instance::method_41753, value -> {
            if (!(value instanceof Boolean flag)) {
                return false;
            }
            instance.method_41748(flag);
            return true;
        });
    }

    private static <E extends Enum<E>> Access enumeration(class_7172<E> instance, Class<E> type) {
        return new Access(() -> instance.method_41753().name(), value -> {
            Optional<E> constant = constant(type, value);
            if (constant.isEmpty()) {
                return false;
            }
            instance.method_41748(constant.get());
            return true;
        });
    }

    private static Access volume(class_315 options, class_3419 source) {
        return number(options.method_45578(source), Number::doubleValue);
    }

    /**
     * Graphics preset: FAST / FANCY / FABULOUS. {@code Options.applyGraphicsPreset} writes every individual graphics
     * option the preset implies (clouds, leaves, transparency, …) exactly like the Video Settings button.
     */
    private static Access graphicsPreset(class_315 options) {
        return new Access(() -> options.method_75329().method_41753().name(), value -> {
            Optional<class_5365> preset = constant(class_5365.class, value);
            if (preset.isEmpty() || preset.get() == class_5365.field_63461) {
                return false;
            }
            options.method_75317(preset.get());
            if (options.method_75329().method_41753() != preset.get()) {
                options.method_75329().method_41748(preset.get());
            }
            return true;
        });
    }

    private static <E extends Enum<E>> Optional<E> constant(Class<E> type, Object value) {
        if (value instanceof Enum<?> e) {
            value = e.name();
        }
        if (!(value instanceof String name)) {
            return Optional.empty();
        }
        try {
            return Optional.of(Enum.valueOf(type, name.trim().toUpperCase(java.util.Locale.ROOT)));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
    }

    // ---- OptionsBridge -----------------------------------------------------------------------------------------

    @Override
    public boolean supports(VanillaOption option) {
        return accessors().containsKey(option);
    }

    @Override
    public Optional<Object> get(VanillaOption option) {
        Access access = accessors().get(option);
        if (access == null) {
            return Optional.empty();
        }
        Object raw = access.getter().get();
        return raw == null ? Optional.empty() : option.normalize(raw);
    }

    @Override
    public boolean set(VanillaOption option, Object value) {
        Access access = accessors().get(option);
        if (access == null) {
            return false;
        }
        Optional<Object> normalized = option.normalize(value);
        return normalized.isPresent() && access.setter().test(normalized.get());
    }

    @Override
    public void save() {
        class_315 options = options();
        if (options != null) {
            options.method_1640();
        }
    }
}
