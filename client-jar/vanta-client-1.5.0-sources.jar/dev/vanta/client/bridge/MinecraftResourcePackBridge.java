package dev.vanta.client.bridge;

import dev.vanta.client.screen.VanillaScreenOpener;
import dev.vanta.core.bridge.PackInfo;
import dev.vanta.core.bridge.ResourcePackBridge;
import dev.vanta.core.bridge.VanillaScreen;
import dev.vanta.core.ui.TextureRef;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_156;
import net.minecraft.class_310;
import net.minecraft.class_3283;
import net.minecraft.class_3288;
import net.minecraft.class_5352;

/**
 * {@link ResourcePackBridge} over the game's {@link class_3283}.
 * <p>
 * Changes are staged in a local selection list (lowest priority first, like {@code getSelectedIds()}) until
 * {@link #apply()} hands it to the repository and to {@code Options.updateResourcePacks}, which saves
 * {@code options.txt} and reloads resources when the selection changed — the exact path the vanilla pack screen uses.
 * If the live selection changes elsewhere (vanilla screen, server packs) the staged list is rebuilt from it.
 */
public final class MinecraftResourcePackBridge implements ResourcePackBridge {
    private final PackIcons icons = new PackIcons();
    private List<String> staged;
    private List<String> stagedBase;

    private static class_3283 repository() {
        class_310 minecraft = class_310.method_1551();
        return minecraft == null ? null : minecraft.method_1520();
    }

    private List<String> staged(class_3283 repository) {
        List<String> live = new ArrayList<>(repository.method_29210());
        if (staged == null || !live.equals(stagedBase)) {
            staged = new ArrayList<>(live);
            stagedBase = live;
        }
        return staged;
    }

    @Override
    public List<PackInfo> packs() {
        class_3283 repository = repository();
        if (repository == null) {
            return List.of();
        }
        List<String> selected = staged(repository);
        List<PackInfo> out = new ArrayList<>();
        for (class_3288 pack : repository.method_14441()) {
            int position = selected.indexOf(pack.method_14463());
            out.add(new PackInfo(pack.method_14463(), pack.method_14457().getString(), pack.method_14459().getString(),
                    pack.method_14460().method_14437(), pack.method_14460().method_14439().getString(),
                    position >= 0, pack.method_14464(), position, sourceLabel(pack.method_29483()),
                    icons.hasIcon(pack)));
        }
        return out;
    }

    /** Label of a pack source in the core's vocabulary (built-in, world, server, feature, file). */
    static String sourceLabel(class_5352 source) {
        if (source == class_5352.field_25348) {
            return "built-in";
        }
        if (source == class_5352.field_25349) {
            return "world";
        }
        if (source == class_5352.field_25350) {
            return "server";
        }
        if (source == class_5352.field_40048) {
            return "feature";
        }
        return "file";
    }

    /** Icon texture of a pack when it has one (registered on first request). */
    public Optional<TextureRef> icon(String id) {
        class_3283 repository = repository();
        if (repository == null) {
            return Optional.empty();
        }
        class_3288 pack = repository.method_14449(id);
        return pack == null ? Optional.empty() : icons.texture(pack);
    }

    @Override
    public boolean setEnabled(String id, boolean enabled) {
        class_3283 repository = repository();
        if (repository == null) {
            return false;
        }
        class_3288 pack = repository.method_14449(id);
        if (pack == null || pack.method_14464()) {
            return false;
        }
        List<String> selected = staged(repository);
        if (enabled) {
            if (selected.contains(id)) {
                return false;
            }
            selected.add(id);
            return true;
        }
        return selected.remove(id);
    }

    @Override
    public boolean move(String id, int delta) {
        class_3283 repository = repository();
        if (repository == null || delta == 0) {
            return false;
        }
        class_3288 pack = repository.method_14449(id);
        if (pack == null || pack.method_14465()) {
            return false;
        }
        List<String> selected = staged(repository);
        int index = selected.indexOf(id);
        if (index < 0) {
            return false;
        }
        int target = Math.max(0, Math.min(selected.size() - 1, index + delta));
        if (target == index) {
            return false;
        }
        class_3288 other = repository.method_14449(selected.get(target));
        if (other != null && other.method_14465()) {
            return false;
        }
        selected.remove(index);
        selected.add(target, id);
        return true;
    }

    @Override
    public boolean hasPendingChanges() {
        class_3283 repository = repository();
        return repository != null && !staged(repository).equals(new ArrayList<>(repository.method_29210()));
    }

    @Override
    public void apply() {
        class_310 minecraft = class_310.method_1551();
        class_3283 repository = repository();
        if (minecraft == null || repository == null || !hasPendingChanges()) {
            return;
        }
        repository.method_14447(new ArrayList<>(staged(repository)));
        minecraft.field_1690.method_49598(repository);
        staged = null;
    }

    @Override
    public void discard() {
        staged = null;
    }

    @Override
    public void openPackFolder() {
        class_310 minecraft = class_310.method_1551();
        if (minecraft != null) {
            class_156.method_668().method_60932(minecraft.method_1479());
        }
    }

    @Override
    public void openVanillaScreen() {
        VanillaScreenOpener.open(VanillaScreen.RESOURCE_PACKS);
    }
}
