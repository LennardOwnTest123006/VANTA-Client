package dev.vanta.client.bridge;

import dev.vanta.client.VantaClient;
import dev.vanta.core.ui.TextureRef;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3262;
import net.minecraft.class_3288;
import net.minecraft.class_7367;

/**
 * Loads resource pack icons ({@code pack.png}) into dynamic textures, exactly like the vanilla pack screen does, and
 * caches the result per pack id. Icons are registered under exactly the identifier the core's
 * {@link dev.vanta.core.screen.packs.PackIcons#texture} expects ({@code vanta:pack_icons/<sanitised id>}) so the
 * resource pack screen can draw them through a {@link TextureRef}.
 */
final class PackIcons {
    private final Map<String, Optional<TextureRef>> cache = new HashMap<>();

    /** True when the pack ships a readable {@code pack.png}. */
    boolean hasIcon(class_3288 pack) {
        return texture(pack).isPresent();
    }

    /** The registered icon texture, loading it on first use. */
    Optional<TextureRef> texture(class_3288 pack) {
        return cache.computeIfAbsent(pack.method_14463(), id -> load(pack));
    }

    private static Optional<TextureRef> load(class_3288 pack) {
        class_310 minecraft = class_310.method_1551();
        if (minecraft == null) {
            return Optional.empty();
        }
        try (class_3262 resources = pack.method_14458()) {
            class_7367<InputStream> supplier = resources.method_14410("pack.png");
            if (supplier == null) {
                return Optional.empty();
            }
            class_1011 image;
            try (InputStream in = supplier.get()) {
                image = class_1011.method_4309(in);
            }
            TextureRef ref = dev.vanta.core.screen.packs.PackIcons.texture(pack.method_14463());
            class_2960 id = class_2960.method_60655(ref.namespace(), ref.path());
            minecraft.method_1531().method_4616(id, new class_1043(() -> "VANTA pack icon " + pack.method_14463(),
                    image));
            return Optional.of(ref);
        } catch (IOException | RuntimeException e) {
            VantaClient.LOGGER.debug("No usable icon for resource pack {}", pack.method_14463(), e);
            return Optional.empty();
        }
    }
}
