package dev.vanta.client.event;

import dev.vanta.client.VantaClient;
import dev.vanta.client.VantaRuntime;
import dev.vanta.client.screen.VantaScreens;
import dev.vanta.core.keybinds.VantaKeys;
import dev.vanta.core.screen.ScreenId;
import dev.vanta.core.search.ActionEntry;
import dev.vanta.core.stats.StatsTracker;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.event.client.player.ClientPlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1132;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_310;
import net.minecraft.class_642;

/**
 * Wires the Fabric client events to the core services: ticking (services, HUD, crosshair, notifications, screenshots,
 * the Vanta Lab input relay), lifecycle saves, statistics sessions and the VANTA key mappings. All handlers are
 * observers of the user's own actions; none changes gameplay.
 */
public final class GameEvents {
    private GameEvents() {
    }

    /** Registers every event handler; call once from the client entrypoint. */
    public static void register(VantaRuntime runtime) {
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> runtime.onClientStarted());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> runtime.shutdown());
        ClientTickEvents.END_CLIENT_TICK.register(client -> onEndTick(runtime, client));
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> onJoin(runtime, client));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> runtime.services().stats().onLeave());
        ClientPlayerBlockBreakEvents.AFTER.register((world, player, pos, state) ->
                runtime.services().stats().onBlockBroken());
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.method_8608() && player.method_5998(hand).method_7909() instanceof class_1747) {
                runtime.services().stats().onBlockPlaced();
            }
            return class_1269.field_5811;
        });
    }

    private static void onEndTick(VantaRuntime runtime, class_310 client) {
        runtime.services().tick();
        runtime.labInputs().tick(client);
        runtime.hud().tick();
        runtime.crosshair().tick();
        runtime.notifications().tick();
        runtime.screenshots().tick();
        runtime.keys().syncZoomKey(runtime.services().settings());
        runtime.keys().pollClicks(id -> onKeyClick(runtime, client, id));
        runtime.scheduler().runPending();
    }

    private static void onKeyClick(VantaRuntime runtime, class_310 client, String id) {
        if (client.field_1755 != null) {
            return;
        }
        switch (id) {
            case VantaKeys.OPEN_MENU -> VantaScreens.open(ScreenId.SETTINGS, null);
            case VantaKeys.TOGGLE_HUD -> runtime.services().runAction(ActionEntry.TOGGLE_HUD);
            case VantaKeys.HUD_EDITOR -> VantaScreens.open(ScreenId.HUD_EDITOR, null);
            case VantaKeys.PERFORMANCE -> VantaScreens.open(ScreenId.PERFORMANCE, null);
            case VantaKeys.OPEN_NEXUS -> VantaScreens.open(ScreenId.NEXUS, null);
            case VantaKeys.SCREENSHOT_HUD_FREE -> runtime.services().runAction(ActionEntry.SCREENSHOT_HUD_FREE);
            default -> {
                // The zoom key is read while held (see ZoomController), not on click.
            }
        }
    }

    private static void onJoin(VantaRuntime runtime, class_310 client) {
        StatsTracker stats = runtime.services().stats();
        if (client.method_1542()) {
            stats.onJoinWorld(worldName(client));
            return;
        }
        class_642 server = client.method_1558();
        if (server != null && server.field_3761 != null && !server.field_3761.isBlank()) {
            stats.onJoinServer(server.field_3761);
        }
    }

    private static String worldName(class_310 client) {
        try {
            class_1132 server = client.method_1576();
            if (server != null) {
                return server.method_27728().method_150();
            }
        } catch (RuntimeException e) {
            VantaClient.LOGGER.debug("Could not read the world name", e);
        }
        return "";
    }
}
