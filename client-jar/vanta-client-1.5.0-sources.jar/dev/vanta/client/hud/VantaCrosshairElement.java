package dev.vanta.client.hud;

import dev.vanta.client.VantaRuntime;
import dev.vanta.client.perf.FrameProbe;
import dev.vanta.client.render.GuiGraphicsCanvas;
import dev.vanta.client.screen.VantaScreens;
import dev.vanta.core.screen.ScreenId;
import java.util.Objects;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

/**
 * Replaces the vanilla crosshair element: draws the custom VANTA crosshair when it is enabled and delegates to the
 * vanilla element otherwise.
 * <p>
 * Vanilla keeps the crosshair in every situation where it carries information the custom style cannot (third-person
 * camera, spectator mode, the F3 debug axes) and while the crosshair editor previews the style itself.
 * <p>
 * The wall time of a custom crosshair draw (not of the vanilla delegate) is reported to the {@link FrameProbe} while
 * the client game test's probe is enabled.
 */
public final class VantaCrosshairElement implements HudElement {
    private final HudElement vanilla;

    /**
     * @param vanilla the element being replaced (Fabric passes it to the replacer)
     */
    public VantaCrosshairElement(HudElement vanilla) {
        this.vanilla = Objects.requireNonNull(vanilla, "vanilla");
    }

    @Override
    public void render(class_332 graphics, class_9779 deltaTracker) {
        VantaRuntime runtime = VantaRuntime.get();
        class_310 minecraft = class_310.method_1551();
        if (runtime == null || minecraft == null || !useCustom(minecraft)) {
            vanilla.render(graphics, deltaTracker);
            return;
        }
        // Evaluated once per frame; the renderer takes the flag so it does not scan the HUD layout a second time.
        boolean customEnabled = runtime.crosshair().isCustomEnabled();
        if (!customEnabled) {
            vanilla.render(graphics, deltaTracker);
            return;
        }
        boolean probe = FrameProbe.isEnabled();
        long start = probe ? System.nanoTime() : 0L;
        int width = graphics.method_51421();
        int height = graphics.method_51443();
        GuiGraphicsCanvas canvas = new GuiGraphicsCanvas(graphics, minecraft.field_1772, width, height, false);
        try {
            runtime.crosshair().render(canvas, width, height, deltaTracker.method_60638(), customEnabled);
        } finally {
            canvas.finish();
            if (probe) {
                FrameProbe.recordCrosshair(System.nanoTime() - start);
            }
        }
    }

    private static boolean useCustom(class_310 minecraft) {
        return minecraft.field_1724 != null
                && !minecraft.field_1690.field_1842
                && !minecraft.field_61504.method_72776()
                && minecraft.field_1690.method_31044().method_31034()
                && !minecraft.field_1724.method_7325()
                && !VantaScreens.isOpen(ScreenId.CROSSHAIR);
    }
}
