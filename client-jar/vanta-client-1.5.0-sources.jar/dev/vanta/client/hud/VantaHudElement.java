package dev.vanta.client.hud;

import dev.vanta.client.VantaRuntime;
import dev.vanta.client.perf.FrameProbe;
import dev.vanta.client.render.GuiGraphicsCanvas;
import dev.vanta.client.screen.VantaScreens;
import dev.vanta.core.screen.ScreenId;
import dev.vanta.core.settings.VantaSettings;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

/**
 * Fabric HUD element that draws the VANTA HUD (all enabled widgets) and, while no screen is open, the notification
 * overlay. Attached after the vanilla chat so it inherits the chat's render condition.
 * <p>
 * Skipped when the GUI is hidden (F1), while the F3 debug overlay is visible, while a HUD-free screenshot is being
 * captured and while the HUD editor is open (the editor draws its own live preview).
 * <p>
 * The wall time of every call is reported to the {@link FrameProbe} while the client game test's probe is enabled.
 */
public final class VantaHudElement implements HudElement {
    @Override
    public void render(class_332 graphics, class_9779 deltaTracker) {
        boolean probe = FrameProbe.isEnabled();
        long start = probe ? System.nanoTime() : 0L;
        try {
            renderHud(graphics, deltaTracker);
        } finally {
            if (probe) {
                FrameProbe.recordHud(System.nanoTime() - start);
            }
        }
    }

    private static void renderHud(class_332 graphics, class_9779 deltaTracker) {
        VantaRuntime runtime = VantaRuntime.get();
        class_310 minecraft = class_310.method_1551();
        if (runtime == null || minecraft == null || minecraft.field_1724 == null) {
            return;
        }
        runtime.frames().onHudFrame(minecraft);
        if (minecraft.field_1690.field_1842 || minecraft.field_61504.method_72776()
                || runtime.screenshots().isHudSuppressed()) {
            return;
        }
        int width = graphics.method_51421();
        int height = graphics.method_51443();
        float delta = deltaTracker.method_60638();
        GuiGraphicsCanvas canvas = new GuiGraphicsCanvas(graphics, minecraft.field_1772, width, height, false);
        try {
            if (runtime.services().settings().get(VantaSettings.HUD_ENABLED) && !VantaScreens.isOpen(ScreenId.HUD_EDITOR)) {
                runtime.hud().render(canvas, width, height, delta);
            }
            if (minecraft.field_1755 == null) {
                runtime.notifications().render(canvas, width, height, delta);
            }
        } finally {
            canvas.finish();
        }
    }
}
