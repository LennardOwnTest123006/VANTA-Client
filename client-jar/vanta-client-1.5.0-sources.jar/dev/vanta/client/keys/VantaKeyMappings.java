package dev.vanta.client.keys;

import dev.vanta.client.VantaClient;
import dev.vanta.client.bridge.KeyConversions;
import dev.vanta.core.bridge.KeyRef;
import dev.vanta.core.keybinds.VantaKeys;
import dev.vanta.core.settings.SettingsStore;
import dev.vanta.core.settings.VantaSettings;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

/**
 * VANTA's key mappings: one {@link class_304} per {@link VantaKeys.Definition} in the {@code vanta:vanta} category
 * (shown as "VANTA" in the vanilla Controls screen).
 * <p>
 * Must be created from the client entrypoint, before the game loads {@code options.txt} (Fabric requires modded
 * mappings to be registered before {@code Options} exists). Clicks are polled once per tick with
 * {@link class_304#method_1436()}; the game only registers clicks while no screen is open.
 * <p>
 * The zoom key is mirrored into the {@code zoom.key} setting in both directions so profiles and the settings screen
 * stay in sync with the vanilla Controls screen.
 */
public final class VantaKeyMappings {
    private final Map<String, class_304> mappings;
    private String lastBoundZoomKey;
    private String lastZoomSetting;

    private VantaKeyMappings(Map<String, class_304> mappings) {
        this.mappings = Collections.unmodifiableMap(mappings);
    }

    /** Creates and registers every VANTA key mapping. Call exactly once from {@code onInitializeClient}. */
    public static VantaKeyMappings register() {
        class_304.class_11900 category = class_304.class_11900.method_74698(class_2960.method_60655("vanta", "vanta"));
        Map<String, class_304> mappings = new LinkedHashMap<>();
        for (VantaKeys.Definition definition : VantaKeys.all()) {
            KeyRef key = definition.defaultKey();
            class_304 mapping = new class_304(definition.id(), KeyConversions.toType(key.type()),
                    key.isUnbound() ? -1 : key.code(), category);
            KeyBindingHelper.registerKeyBinding(mapping);
            mappings.put(definition.id(), mapping);
        }
        return new VantaKeyMappings(mappings);
    }

    /** The mapping for a {@link VantaKeys} id. */
    public Optional<class_304> get(String id) {
        return Optional.ofNullable(mappings.get(id));
    }

    /** True while the mapping is held down. */
    public boolean isDown(String id) {
        class_304 mapping = mappings.get(id);
        return mapping != null && mapping.method_1434();
    }

    /** Delivers every click registered since the last poll, in definition order. */
    public void pollClicks(Consumer<String> onClick) {
        Objects.requireNonNull(onClick, "onClick");
        for (Map.Entry<String, class_304> entry : mappings.entrySet()) {
            while (entry.getValue().method_1436()) {
                onClick.accept(entry.getKey());
            }
        }
    }

    /**
     * Keeps {@code zoom.key} and the zoom mapping identical. A rebinding in the Controls screen wins over the setting;
     * a settings change (profile load, settings screen) is pushed to the mapping and saved to {@code options.txt}.
     */
    public void syncZoomKey(SettingsStore settings) {
        class_304 zoom = mappings.get(VantaKeys.ZOOM);
        class_310 minecraft = class_310.method_1551();
        if (zoom == null || minecraft == null || minecraft.field_1690 == null) {
            return;
        }
        String bound = KeyBindingHelper.getBoundKeyOf(zoom).method_1441();
        String setting = settings.get(VantaSettings.ZOOM_KEY);
        if (lastBoundZoomKey == null) {
            // First sync after start-up: options.txt is authoritative.
            lastBoundZoomKey = bound;
            lastZoomSetting = setting;
            if (!bound.equals(setting)) {
                settings.set(VantaSettings.ZOOM_KEY, bound);
                lastZoomSetting = bound;
            }
            return;
        }
        if (!bound.equals(lastBoundZoomKey)) {
            settings.set(VantaSettings.ZOOM_KEY, bound);
            lastBoundZoomKey = bound;
            lastZoomSetting = bound;
            return;
        }
        if (!setting.equals(lastZoomSetting)) {
            Optional<class_3675.class_306> key = KeyConversions.fromVanillaName(setting);
            if (key.isPresent()) {
                zoom.method_1422(key.get());
                class_304.method_1426();
                minecraft.field_1690.method_1640();
                lastBoundZoomKey = key.get().method_1441();
            } else {
                VantaClient.LOGGER.warn("Ignoring unknown zoom key name '{}' in settings", setting);
            }
            lastZoomSetting = setting;
        }
    }
}
