package dev.vanta.client.render;

import dev.vanta.client.perf.FrameProbe;
import dev.vanta.core.ui.AbstractCanvas;
import dev.vanta.core.ui.Canvas;
import dev.vanta.core.ui.Colors;
import dev.vanta.core.ui.FontKind;
import dev.vanta.core.ui.Rect;
import dev.vanta.core.ui.RoundedCorners;
import dev.vanta.core.ui.TextureRef;
import java.util.Objects;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9848;

/**
 * The core {@link dev.vanta.core.ui.Canvas} implemented on top of {@link class_332}.
 * <p>
 * One instance is created per frame for the surface being drawn (a screen, the HUD, a vanilla screen overlay).
 * {@link AbstractCanvas} owns the transform stack, the scissor intersection and the partial-alpha multiplier; this
 * class maps the resulting primitives to the game:
 * <ul>
 *   <li>fills go to {@link class_332#method_25294}, vertical gradients to {@link class_332#method_25296} and horizontal
 *       gradients to one {@link class_332#method_25296} under a rotated pose (see {@link #fillGradientH}); every
 *       other shape (rounded corners, lines, circles) is composed of fills by the core defaults so it looks identical
 *       to the Java2D previews;</li>
 *   <li>text is drawn with {@link class_332#method_25303} using a {@link net.minecraft.class_2561} styled with
 *       the VANTA font provider ({@link VantaFonts}), or as a plain string for the vanilla font;</li>
 *   <li>images use {@link class_332#method_70845} with {@link class_10799#field_56883}; partial alpha is applied through the
 *       colour tint argument;</li>
 *   <li>transforms push onto {@link class_332#method_51448()} so every draw call is transformed by the game itself;</li>
 *   <li>clips are applied with {@link class_332#method_44379} under an identity pose, because the game transforms the
 *       scissor rectangle by the current pose while {@link AbstractCanvas} already supplies device coordinates. The game
 *       keeps only one scissor active at a time here; nesting is resolved by the core's intersection logic.</li>
 * </ul>
 * Colours with an alpha below 4 are skipped for text because the vanilla font treats such colours as opaque.
 */
public final class GuiGraphicsCanvas extends AbstractCanvas {
    /** Pose rotation that turns the game's vertical gradient into a left-to-right one (see {@link #fillGradientH}). */
    private static final float QUARTER_TURN_LEFT = (float) (-Math.PI / 2.0);

    private final class_332 graphics;
    private final class_327 font;
    private final boolean allowBlur;
    private boolean nativeScissorActive;
    private boolean blurred;

    /**
     * @param graphics  the frame's graphics
     * @param font      the game font
     * @param width     surface width in GUI pixels
     * @param height    surface height in GUI pixels
     * @param allowBlur whether {@link #blurBackground()} may request the one blur the game allows per frame (only the
     *                  screen canvas may; HUD and overlay canvases pass {@code false})
     */
    public GuiGraphicsCanvas(class_332 graphics, class_327 font, int width, int height, boolean allowBlur) {
        super(width, height);
        this.graphics = Objects.requireNonNull(graphics, "graphics");
        this.font = Objects.requireNonNull(font, "font");
        this.allowBlur = allowBlur;
    }

    /** The wrapped graphics (for callers that need vanilla drawing next to core drawing). */
    public class_332 graphics() {
        return graphics;
    }

    // ---- primitives --------------------------------------------------------------------------------------------

    @Override
    protected void fillImpl(int x, int y, int w, int h, int argb) {
        FrameProbe.countFill();
        graphics.method_25294(x, y, x + w, y + h, argb);
    }

    @Override
    public void fillGradientV(int x, int y, int w, int h, int argbTop, int argbBottom) {
        if (w <= 0 || h <= 0) {
            return;
        }
        int top = applyAlpha(argbTop);
        int bottom = applyAlpha(argbBottom);
        if (Colors.alpha(top) == 0 && Colors.alpha(bottom) == 0) {
            return;
        }
        FrameProbe.countGradient();
        graphics.method_25296(x, y, x + w, y + h, top, bottom);
    }

    /**
     * One native gradient instead of one fill per column: the game only interpolates along its y axis, so the pose
     * is rotated a quarter turn and the gradient is drawn sideways.
     * <p>
     * Derivation: {@code world = Translate(x, y) * Rotate(theta) * local} with the standard rotation matrix
     * {@code [cos -sin; sin cos]} (what {@code Matrix3x2fStack.rotate(float)} applies) and {@code theta = -PI/2}
     * ({@code cos 0, sin -1}) maps a local point {@code (lx, ly)} to {@code (x + ly, y - lx)}: local +Y becomes world
     * +X and local +X becomes world -Y. The local rectangle {@code lx in [-h, 0], ly in [0, w]} therefore covers
     * exactly world {@code [x, x + w] x [y, y + h]}, and since {@code fillGradient} varies the colour along local +Y
     * from the first colour at {@code y1} to the second at {@code y2}, {@code argbLeft} lands on the left edge and
     * {@code argbRight} on the right edge. Anchoring the rotation at the corner rather than the centre keeps every
     * coordinate integral for odd widths and heights.
     */
    @Override
    public void fillGradientH(int x, int y, int w, int h, int argbLeft, int argbRight) {
        if (w <= 0 || h <= 0) {
            return;
        }
        if (argbLeft == argbRight) {
            fill(x, y, w, h, argbLeft);
            return;
        }
        int left = applyAlpha(argbLeft);
        int right = applyAlpha(argbRight);
        if (Colors.alpha(left) == 0 && Colors.alpha(right) == 0) {
            return;
        }
        FrameProbe.countGradient();
        graphics.method_51448().pushMatrix();
        graphics.method_51448().translate(x, y);
        graphics.method_51448().rotate(QUARTER_TURN_LEFT);
        graphics.method_25296(-h, 0, 0, w, left, right);
        graphics.method_51448().popMatrix();
    }

    /**
     * Rounded horizontal gradient as one native gradient for the centre band plus one per corner row, using the same
     * inset table as {@link Canvas#fillRounded} and {@link Canvas#strokeRounded} so the corners still line up. Each
     * corner row starts and ends with the colour the full-width gradient has at that column, exactly like the
     * per-column default.
     */
    @Override
    public void fillRoundedGradientH(int x, int y, int w, int h, int radius, int argbLeft, int argbRight) {
        int r = Canvas.clampRadius(radius, w, h);
        if (w <= 0 || h <= 0) {
            return;
        }
        if (r <= 0) {
            fillGradientH(x, y, w, h, argbLeft, argbRight);
            return;
        }
        int[] insets = RoundedCorners.insets(r);
        fillGradientH(x, y + r, w, h - 2 * r, argbLeft, argbRight);
        for (int i = 0; i < r; i++) {
            int inset = insets[i];
            int rowWidth = w - 2 * inset;
            if (rowWidth <= 0) {
                continue;
            }
            int rowLeft = w == 1 ? argbLeft : Colors.lerp(argbLeft, argbRight, inset / (float) (w - 1));
            int rowRight = w == 1 ? argbLeft : Colors.lerp(argbLeft, argbRight, (w - 1 - inset) / (float) (w - 1));
            fillGradientH(x + inset, y + i, rowWidth, 1, rowLeft, rowRight);
            fillGradientH(x + inset, y + h - 1 - i, rowWidth, 1, rowLeft, rowRight);
        }
    }

    @Override
    protected void textImpl(String text, int x, int y, int argb, FontKind kind, boolean shadow) {
        if (Colors.alpha(argb) < 4) {
            return;
        }
        FrameProbe.countText();
        if (VantaFonts.isCustom(kind)) {
            graphics.method_51439(font, VantaFonts.styled(text, kind), x, y, argb, shadow);
        } else {
            graphics.method_51433(font, text, x, y, argb, shadow);
        }
    }

    @Override
    protected void imageImpl(TextureRef texture, int x, int y, int w, int h, float u, float v, float uw, float vh,
                             int texW, int texH, float alpha) {
        if (alpha <= 0f) {
            return;
        }
        FrameProbe.countImage();
        class_2960 id = class_2960.method_60655(texture.namespace(), texture.path());
        int regionW = Math.max(1, Math.round(uw));
        int regionH = Math.max(1, Math.round(vh));
        int tint = class_9848.method_61317(Math.min(1f, alpha));
        graphics.method_25293(class_10799.field_56883, id, x, y, u, v, w, h, regionW, regionH, Math.max(1, texW),
                Math.max(1, texH), tint);
    }

    // ---- text metrics ------------------------------------------------------------------------------------------

    @Override
    public int textWidth(String text, FontKind kind) {
        return MinecraftTextMetrics.measure(font, text, kind == null ? FontKind.UI : kind);
    }

    @Override
    public int lineHeight(FontKind kind) {
        return VantaFonts.lineHeight(kind == null ? FontKind.UI : kind);
    }

    // ---- transforms --------------------------------------------------------------------------------------------

    @Override
    protected void onPushTranslate(float dx, float dy) {
        FrameProbe.countTransformPush();
        graphics.method_51448().pushMatrix();
        graphics.method_51448().translate(dx, dy);
    }

    @Override
    protected void onPushScale(float sx, float sy) {
        FrameProbe.countTransformPush();
        graphics.method_51448().pushMatrix();
        graphics.method_51448().scale(sx, sy);
    }

    @Override
    protected void onPopTransform(Transform restored) {
        graphics.method_51448().popMatrix();
    }

    // ---- scissor -----------------------------------------------------------------------------------------------

    @Override
    protected void onScissorChanged(Rect deviceClip) {
        FrameProbe.countScissorChange();
        if (nativeScissorActive) {
            graphics.method_44380();
            nativeScissorActive = false;
        }
        if (deviceClip == null) {
            return;
        }
        int x1 = deviceClip.x();
        int y1 = deviceClip.y();
        int x2 = Math.max(x1, deviceClip.right());
        int y2 = Math.max(y1, deviceClip.bottom());
        graphics.method_51448().pushMatrix();
        graphics.method_51448().identity();
        graphics.method_44379(x1, y1, x2, y2);
        graphics.method_51448().popMatrix();
        nativeScissorActive = true;
    }

    // ---- blur --------------------------------------------------------------------------------------------------

    /**
     * Requests the menu background blur. The game allows a single blur per frame, so only the screen canvas may ask
     * for it, only once, and only while a world is rendered behind the screen.
     */
    @Override
    public void blurBackground() {
        if (!allowBlur || blurred) {
            return;
        }
        class_310 minecraft = class_310.method_1551();
        if (minecraft == null || minecraft.field_1687 == null) {
            return;
        }
        blurred = true;
        graphics.method_71278();
    }

    /** Releases a still-active native scissor; call when the frame's drawing is complete. */
    public void finish() {
        if (nativeScissorActive) {
            graphics.method_44380();
            nativeScissorActive = false;
        }
    }
}
