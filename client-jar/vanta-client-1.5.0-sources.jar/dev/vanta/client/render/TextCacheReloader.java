package dev.vanta.client.render;

import net.minecraft.class_3300;
import net.minecraft.class_4013;

/**
 * Client resource reloader that clears the memoised text widths ({@link MinecraftTextMetrics}) and styled components
 * ({@link VantaFonts}) whenever the game's resources reload: a resource pack can replace the font providers, which
 * changes the glyph advances the cached widths were measured with. Registered by {@code VantaClient}.
 */
public final class TextCacheReloader implements class_4013 {
    @Override
    public void method_14491(class_3300 resourceManager) {
        MinecraftTextMetrics.clearCache();
        VantaFonts.clearCache();
    }
}
