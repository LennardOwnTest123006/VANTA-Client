package dev.vanta.client.screen;

import dev.vanta.client.VantaRuntime;
import dev.vanta.core.bridge.VanillaScreen;
import dev.vanta.core.screen.ScreenId;
import dev.vanta.core.settings.VantaSettings;
import dev.vanta.core.ui.UiHost;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1109;
import net.minecraft.class_310;
import net.minecraft.class_3417;

/**
 * {@link UiHost} for one {@link VantaScreen}: navigation, clipboard, click sound and links, all through the public
 * Minecraft API. Opening another VANTA screen makes the current one its parent so "Back" returns here.
 */
final class MinecraftUiHost implements UiHost {
    private final VantaScreen screen;
    private final VantaRuntime runtime;

    MinecraftUiHost(VantaScreen screen, VantaRuntime runtime) {
        this.screen = Objects.requireNonNull(screen, "screen");
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    @Override
    public void closeScreen() {
        screen.closeNow();
    }

    @Override
    public void openScreen(Object screenId) {
        if (screenId instanceof ScreenId id) {
            VantaScreens.open(id, screen);
        } else if (screenId instanceof VanillaScreen vanilla) {
            VanillaScreenOpener.open(vanilla);
        } else if (screenId instanceof String text) {
            Optional<ScreenId> id = ScreenId.fromId(text);
            if (id.isPresent()) {
                VantaScreens.open(id.get(), screen);
            } else {
                VanillaScreenOpener.openByName(text);
            }
        }
    }

    @Override
    public void setClipboard(String text) {
        class_310 minecraft = class_310.method_1551();
        if (minecraft != null && minecraft.field_1774 != null) {
            minecraft.field_1774.method_1455(text == null ? "" : text);
        }
    }

    @Override
    public String getClipboard() {
        class_310 minecraft = class_310.method_1551();
        if (minecraft == null || minecraft.field_1774 == null) {
            return "";
        }
        String text = minecraft.field_1774.method_1460();
        return text == null ? "" : text;
    }

    @Override
    public void playClick() {
        if (!runtime.services().settings().get(VantaSettings.GENERAL_UI_SOUNDS)) {
            return;
        }
        class_310 minecraft = class_310.method_1551();
        if (minecraft != null) {
            minecraft.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
        }
    }

    @Override
    public void openUrl(String url) {
        VanillaScreenOpener.openUrl(url);
    }

    @Override
    public void requestLayout() {
        screen.requestLayout();
    }
}
