package dev.vanta.client.screen;

import dev.vanta.core.bridge.VanillaScreen;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Locale;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_407;
import net.minecraft.class_4189;
import net.minecraft.class_426;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_443;
import net.minecraft.class_446;
import net.minecraft.class_500;
import net.minecraft.class_526;
import net.minecraft.class_5375;
import net.minecraft.class_6599;

/**
 * Opens vanilla screens and external links on behalf of the core. The current screen becomes the parent so the
 * vanilla "Done" button returns to the VANTA screen the user came from.
 */
public final class VanillaScreenOpener {
    private VanillaScreenOpener() {
    }

    /** Opens the vanilla screen on top of the current one. */
    public static void open(VanillaScreen screen) {
        class_310 minecraft = class_310.method_1551();
        class_437 parent = minecraft.field_1755;
        class_437 next = switch (screen) {
            case SINGLEPLAYER -> new class_526(parent);
            case MULTIPLAYER -> new class_500(parent);
            case OPTIONS -> new class_429(parent, minecraft.field_1690);
            case LANGUAGE -> new class_426(parent, minecraft.field_1690, minecraft.method_1526());
            case RESOURCE_PACKS -> new class_5375(minecraft.method_1520(), repository -> {
                minecraft.field_1690.method_49598(repository);
                minecraft.method_1507(parent);
            }, minecraft.method_1479(), class_2561.method_43471("resourcePack.title"));
            case ACCESSIBILITY -> new class_4189(parent, minecraft.field_1690);
            case CONTROLS -> new class_6599(parent, minecraft.field_1690);
            case VIDEO -> new class_446(parent, minecraft, minecraft.field_1690);
            case AUDIO -> new class_443(parent, minecraft.field_1690);
        };
        minecraft.method_1507(next);
    }

    /** Opens a vanilla screen by its {@link VanillaScreen} constant name (case-insensitive); unknown names are ignored. */
    public static void openByName(String name) {
        if (name == null) {
            return;
        }
        for (VanillaScreen screen : VanillaScreen.values()) {
            if (screen.name().equalsIgnoreCase(name.trim())) {
                open(screen);
                return;
            }
        }
    }

    /**
     * Opens a link. {@code file:} URIs (the config folder, the screenshot folder) open directly in the system file
     * browser; web links go through the vanilla confirmation screen first, exactly like chat links.
     */
    public static void openUrl(String url) {
        if (url == null || url.isBlank()) {
            return;
        }
        String lower = url.toLowerCase(Locale.ROOT);
        if (lower.startsWith("file:")) {
            try {
                class_156.method_668().method_673(new URI(url));
            } catch (URISyntaxException e) {
                class_156.method_668().method_670(url);
            }
            return;
        }
        if (lower.startsWith("http://") || lower.startsWith("https://")) {
            class_310 minecraft = class_310.method_1551();
            class_407.method_60866(minecraft.field_1755, url, true);
        }
    }
}
