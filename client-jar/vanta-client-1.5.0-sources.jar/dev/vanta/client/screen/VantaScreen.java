package dev.vanta.client.screen;

import dev.vanta.client.VantaRuntime;
import dev.vanta.client.perf.FrameProbe;
import dev.vanta.client.render.GuiGraphicsCanvas;
import dev.vanta.client.render.MinecraftTextMetrics;
import dev.vanta.core.cosmetics.MenuBackground;
import dev.vanta.core.i18n.Lang;
import dev.vanta.core.screen.ScreenId;
import dev.vanta.core.settings.VantaSettings;
import dev.vanta.core.ui.Theme;
import dev.vanta.core.ui.UiEnvironment;
import dev.vanta.core.ui.UiScreen;
import java.util.Objects;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * Hosts a core {@link UiScreen} inside a vanilla {@link class_437}.
 * <p>
 * The vanilla screen is a thin shell: it forwards size, rendering, ticks and input to the core screen, which owns all
 * widgets, focus handling, animations and its own background (dim + optional blur). The host only paints what the core
 * cannot: outside a world it draws the vanilla panorama or an opaque base colour so screens never float over black.
 * <p>
 * Lifecycle: {@code init} (also after resizes) → {@code ui.init}; {@code removed} → {@code ui.onClose} exactly once;
 * {@link #closeNow()} (called by the core after its close transition, or by vanilla's {@code onClose}) returns to the
 * parent screen.
 */
public final class VantaScreen extends class_437 {
    private final ScreenId id;
    private final UiScreen ui;
    private final class_437 parent;
    private final VantaRuntime runtime;
    private boolean closed;

    /**
     * @param id      which VANTA screen this is
     * @param ui      the core screen (fresh instance from the registry)
     * @param parent  screen to return to when closed, {@code null} for the game / vanilla title flow
     * @param runtime the client runtime (theme, overlays)
     */
    public VantaScreen(ScreenId id, UiScreen ui, class_437 parent, VantaRuntime runtime) {
        super(class_2561.method_43470(ui.title()));
        this.id = Objects.requireNonNull(id, "id");
        this.ui = ui;
        this.parent = parent;
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        ui.attach(new UiEnvironment(new MinecraftUiHost(this, runtime), runtime.theme(), runtime.uiClock(),
                MinecraftTextMetrics.INSTANCE, Lang::tr));
    }

    /** Which VANTA screen is hosted. */
    public ScreenId screenId() {
        return id;
    }

    /** The hosted core screen. */
    public UiScreen ui() {
        return ui;
    }

    /** The screen shown when this one closes (may be {@code null}). */
    public class_437 parent() {
        return parent;
    }

    // ---- lifecycle ---------------------------------------------------------------------------------------------

    @Override
    protected void method_25426() {
        syncTheme();
        ui.init(field_22789, field_22790);
        if (id == ScreenId.MAIN_MENU) {
            // Next to the core's main menu hooks (Performance pack offer): the one-time Vanta Nexus notice.
            NexusFirstStart.onMainMenuShown(this, runtime);
        }
    }

    @Override
    public void method_25393() {
        syncTheme();
        ui.tick();
    }

    /**
     * The runtime replaces its theme instance only on a real change, so the per-tick check is an identity compare;
     * the equality fallback only runs when a core screen applied an equal theme instance of its own.
     */
    private void syncTheme() {
        Theme current = runtime.theme();
        if (ui.context() != null && current != ui.theme() && !current.equals(ui.theme())) {
            ui.setTheme(current);
        }
    }

    /** Re-runs the core layout before the next frame. */
    void requestLayout() {
        ui.invalidateLayout();
    }

    /** Leaves this screen for its parent immediately (the core has already played its close transition). */
    void closeNow() {
        field_22787.method_1507(parent);
    }

    /** Vanilla asked the screen to close (never from Escape: see {@link #method_25422()}). */
    @Override
    public void method_25419() {
        closeNow();
    }

    @Override
    public void method_25432() {
        if (!closed) {
            closed = true;
            ui.onClose();
        }
    }

    @Override
    public boolean method_25421() {
        return ui.isPauseScreen();
    }

    /** Escape is handled by the core screen (close transition), never by the vanilla shortcut. */
    @Override
    public boolean method_25422() {
        return false;
    }

    // ---- rendering ---------------------------------------------------------------------------------------------

    /**
     * Base layer. In a world the core screen dims and blurs the game itself; outside a world this paints the vanilla
     * panorama when the menu background style asks for it, otherwise the theme's void colour.
     */
    @Override
    public void method_25420(class_332 graphics, int mouseX, int mouseY, float deltaTicks) {
        if (field_22787.field_1687 != null) {
            return;
        }
        MenuBackground style = runtime.services().settings().get(VantaSettings.MENU_BACKGROUND);
        if (style == MenuBackground.VANILLA_PANORAMA) {
            method_57728(graphics, deltaTicks);
        } else {
            graphics.method_25294(0, 0, field_22789, field_22790, runtime.theme().bgVoid());
        }
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float deltaTicks) {
        runtime.frames().onScreenFrame(field_22787);
        boolean probe = FrameProbe.isEnabled();
        long start = probe ? System.nanoTime() : 0L;
        GuiGraphicsCanvas canvas = new GuiGraphicsCanvas(graphics, field_22793, field_22789, field_22790, true);
        try {
            ui.render(canvas, mouseX, mouseY, deltaTicks);
            runtime.notifications().render(canvas, field_22789, field_22790, deltaTicks);
        } finally {
            canvas.finish();
            if (probe) {
                FrameProbe.recordScreen(System.nanoTime() - start);
            }
        }
    }

    // ---- input -------------------------------------------------------------------------------------------------

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        return ui.mouseDown(event.comp_4798(), event.comp_4799(), event.method_74245());
    }

    @Override
    public boolean method_25406(class_11909 event) {
        return ui.mouseUp(event.comp_4798(), event.comp_4799(), event.method_74245());
    }

    @Override
    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        return ui.mouseDrag(event.comp_4798(), event.comp_4799(), event.method_74245(), dragX, dragY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        return ui.mouseScroll(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (ui.keyDown(event.comp_4795(), event.comp_4796(), event.comp_4797())) {
            return true;
        }
        return super.method_25404(event);
    }

    @Override
    public boolean method_16803(class_11908 event) {
        if (ui.keyUp(event.comp_4795(), event.comp_4796(), event.comp_4797())) {
            return true;
        }
        return super.method_16803(event);
    }

    @Override
    public boolean method_25400(class_11905 event) {
        if (ui.charTyped(event.comp_4793(), event.comp_4794())) {
            return true;
        }
        return super.method_25400(event);
    }
}
