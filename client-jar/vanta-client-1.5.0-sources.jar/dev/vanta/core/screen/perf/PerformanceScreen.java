package dev.vanta.core.screen.perf;

import dev.vanta.core.bridge.GameBridge;
import dev.vanta.core.bridge.OptionsBridge;
import dev.vanta.core.i18n.Lang;
import dev.vanta.core.modrinth.ModrinthService;
import dev.vanta.core.perf.MemorySampler;
import dev.vanta.core.perf.PerformanceCenter;
import dev.vanta.core.perf.PerformancePreset;
import dev.vanta.core.perf.PerformanceSnapshot;
import dev.vanta.core.perf.RenderDistanceAdvisor;
import dev.vanta.core.perf.SmartBoostState;
import dev.vanta.core.perf.SmartBoostTuner;
import dev.vanta.core.perf.SystemInfo;
import dev.vanta.core.screen.ScreenId;
import dev.vanta.core.screen.VantaServices;
import dev.vanta.core.screen.common.InfoBanner;
import dev.vanta.core.screen.common.LabelValueRow;
import dev.vanta.core.screen.common.ResponsiveGrid;
import dev.vanta.core.screen.common.ScreenNavigator;
import dev.vanta.core.screen.common.SettingFormats;
import dev.vanta.core.screen.common.SettingRow;
import dev.vanta.core.screen.common.Sparkline;
import dev.vanta.core.screen.common.VantaUiScreen;
import dev.vanta.core.search.ActionEntry;
import dev.vanta.core.settings.Setting;
import dev.vanta.core.settings.SettingsListener;
import dev.vanta.core.settings.VantaSettings;
import dev.vanta.core.ui.Canvas;
import dev.vanta.core.ui.Colors;
import dev.vanta.core.ui.FontKind;
import dev.vanta.core.ui.Icons;
import dev.vanta.core.ui.Rect;
import dev.vanta.core.ui.Size;
import dev.vanta.core.ui.Theme;
import dev.vanta.core.ui.UiContext;
import dev.vanta.core.ui.UiNode;
import dev.vanta.core.ui.VantaShell;
import dev.vanta.core.ui.layout.Align;
import dev.vanta.core.ui.layout.Column;
import dev.vanta.core.ui.layout.Row;
import dev.vanta.core.ui.layout.ScrollPanel;
import dev.vanta.core.ui.layout.Spacer;
import dev.vanta.core.ui.widget.Badge;
import dev.vanta.core.ui.widget.Button;
import dev.vanta.core.ui.widget.Card;
import dev.vanta.core.ui.widget.Label;
import dev.vanta.core.ui.widget.Tabs;
import dev.vanta.core.bridge.VanillaOption;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * The Performance Center: live cards (frame rate with a 60-sample sparkline, frame times, memory, render and
 * simulation distance, system), the render distance advisor's pending suggestion, the one-click "Boost FPS", the
 * BOOST / LOW / BALANCED / HIGH / ULTRA presets with a table of exactly which vanilla options would change, and the
 * safe individual video options as rows. Everything written here is a vanilla option; the renderer itself is never
 * touched, and presets never cap the frame rate.
 * <p>
 * Live values come from {@link GameBridge} through {@link PerformanceCenter#snapshot()} once per client tick.
 */
public final class PerformanceScreen extends VantaUiScreen {
    /** Frame rate samples kept for the sparkline. */
    public static final int HISTORY = 60;
    /** Cards narrower than this are stacked. */
    public static final int MIN_CARD_W = 168;

    private static final List<Setting<?>> QUICK_OPTIONS = List.of(
            VantaSettings.VIDEO_FRAMERATE_LIMIT, VantaSettings.VIDEO_VSYNC, VantaSettings.VIDEO_PARTICLES,
            VantaSettings.VIDEO_CLOUDS, VantaSettings.VIDEO_SMOOTH_LIGHTING, VantaSettings.VIDEO_ENTITY_SHADOWS,
            VantaSettings.VIDEO_ENTITY_DISTANCE, VantaSettings.VIDEO_BIOME_BLEND, VantaSettings.VIDEO_MIPMAP_LEVELS,
            VantaSettings.VIDEO_VIEW_BOBBING);

    private final PerformanceCenter perf;
    private final GameBridge game;
    private final OptionsBridge options;
    private final SystemInfo system = SystemInfo.current();
    private final int[] fpsHistory = new int[HISTORY];
    private int historyHead;
    private int historySize;
    private PerformanceSnapshot snapshot;
    private PerformancePreset selectedPreset;
    private final List<SettingRow> rows = new ArrayList<>();
    private final List<SettingRow> smartRows = new ArrayList<>();
    private final SettingsListener externalChange = change -> onSettingsChanged();

    private VantaShell shell;
    private ScrollPanel scroll;
    private Column content;
    private InfoBanner noWorldBanner;
    private InfoBanner suggestionBanner;
    private Sparkline sparkline;
    private FpsReadout fpsReadout;
    private LabelValueRow frameAvg;
    private LabelValueRow frameLow;
    private LabelValueRow frameMax;
    private LabelValueRow target;
    private MemoryBar memoryBar;
    private LabelValueRow memoryUsed;
    private LabelValueRow memoryAllocated;
    private LabelValueRow memoryMax;
    private LabelValueRow entities;
    private LabelValueRow cpu;
    private Tabs presetTabs;
    private Label presetDescription;
    private Badge currentPreset;
    private PresetDiffTable diffTable;
    private Label diffSummary;
    private Button applyPreset;
    private Button boostFps;
    private Label smartStatus;
    private Label smartCappedNote;
    private Label smartReleased;
    private Label smartHardware;
    private Button smartRetune;
    private Button smartUndo;
    private String smartSignature = "";

    public PerformanceScreen(VantaServices services, ScreenNavigator navigator) {
        super(services, navigator, ScreenId.PERFORMANCE);
        this.perf = services.performance();
        this.game = services.game();
        this.options = services.options();
        perf.reconcileFpsLimitChoice(); // settings.json only: the frame-rate choice follows the game's real limit
        this.snapshot = perf.snapshot();
        this.selectedPreset = snapshot.activePreset().orElse(services.settings().get(VantaSettings.PERFORMANCE_PRESET));
        seedHistory();
    }

    /** Seeds the fps history from the frame-time tracker so the graph is not empty when the screen opens. */
    private void seedHistory() {
        double[] frames = perf.frameTimes().samplesOldestFirst();
        int from = Math.max(0, frames.length - HISTORY);
        for (int i = from; i < frames.length; i++) {
            if (frames[i] > 0) {
                pushFps((int) Math.round(1000.0 / frames[i]));
            }
        }
    }

    private void pushFps(int fps) {
        fpsHistory[historyHead] = Math.max(0, fps);
        historyHead = (historyHead + 1) % HISTORY;
        historySize = Math.min(HISTORY, historySize + 1);
    }

    // ---------------------------------------------------------------- accessors (tests)

    /** Frame rate samples, oldest first. */
    public int[] fpsHistory() {
        int[] out = new int[historySize];
        int start = historySize < HISTORY ? 0 : historyHead;
        for (int i = 0; i < historySize; i++) {
            out[i] = fpsHistory[(start + i) % HISTORY];
        }
        return out;
    }

    /** Latest snapshot. */
    public PerformanceSnapshot snapshot() {
        return snapshot;
    }

    /** Preset selected in the tabs (not necessarily applied). */
    public PerformancePreset selectedPreset() {
        return selectedPreset;
    }

    /** Diff of the selected preset against the current options. */
    public PresetDiff selectedDiff() {
        return PresetDiff.compute(selectedPreset, options);
    }

    public Button applyPresetButton() {
        return applyPreset;
    }

    /** The one-click "Boost FPS" button at the top of the preset card. */
    public Button boostFpsButton() {
        return boostFps;
    }

    public Tabs presetTabs() {
        return presetTabs;
    }

    public Optional<InfoBanner> suggestionBanner() {
        return suggestionBanner != null && suggestionBanner.isVisible() ? Optional.of(suggestionBanner) : Optional.empty();
    }

    /** Rows of the quick options card. */
    public List<SettingRow> quickRows() {
        return List.copyOf(rows);
    }

    /** Smart Boost's "Re-tune" button. */
    public Button smartBoostRetuneButton() {
        return smartRetune;
    }

    /** Smart Boost's "Undo" button. */
    public Button smartBoostUndoButton() {
        return smartUndo;
    }

    /** Smart Boost's status line as shown. */
    public String smartBoostStatus() {
        return smartStatus == null ? "" : smartStatus.text();
    }

    /** The scroll panel holding every card (tests scroll it to reach the lower cards). */
    public ScrollPanel scrollPanel() {
        return scroll;
    }

    // ---------------------------------------------------------------- build

    @Override
    protected UiNode build(UiContext ctx) {
        Theme theme = ctx.theme();
        shell = new VantaShell(Lang.tr("vanta.perf.title"), this::close);
        shell.backTooltip(Lang.tr("vanta.common.back"));
        content = new Column(Theme.SPACE_5);

        noWorldBanner = new InfoBanner(InfoBanner.Tone.NEUTRAL, Lang.tr("vanta.perf.no_world"),
                Lang.tr("vanta.perf.no_world.description")).icon(Icons.INFO);
        noWorldBanner.setId("perf.noWorld");
        content.add(noWorldBanner);
        suggestionBanner = new InfoBanner(InfoBanner.Tone.INFO, "", "");
        suggestionBanner.setId("perf.suggestion");
        suggestionBanner.action(Button.primary(Lang.tr("vanta.perf.apply_suggestion"), this::acceptSuggestion)
                .compact(true));
        suggestionBanner.action(Button.ghost(Lang.tr("vanta.perf.dismiss"), this::dismissSuggestion).compact(true));
        content.add(suggestionBanner);

        ResponsiveGrid cards = new ResponsiveGrid(MIN_CARD_W, 3, Theme.SPACE_4);
        cards.add(fpsCard());
        cards.add(frameTimeCard());
        cards.add(memoryCard());
        cards.add(distanceCard());
        cards.add(systemCard());
        content.add(cards);

        InfoBanner packBanner = new InfoBanner(InfoBanner.Tone.INFO, Lang.tr("vanta.perf.pack.title"),
                Lang.tr("vanta.perf.pack.body")).icon(Icons.DOWNLOAD);
        Button openMods = Button.primary(Lang.tr("vanta.action.open_mods"),
                () -> navigator().openScreen(context(), ScreenId.MODS)).compact(true);
        openMods.setId("perf.openMods");
        packBanner.action(openMods);
        packBanner.setId("perf.pack");
        content.add(packBanner);

        content.add(smartBoostCard());
        content.add(presetCard());
        content.add(quickOptionsCard());
        content.add(new InfoBanner(InfoBanner.Tone.NEUTRAL, Lang.tr("vanta.perf.honest_note.title"),
                Lang.tr("vanta.perf.honest_note")).icon(Icons.LOCK));

        scroll = new ScrollPanel(content).edgeFade(Colors.withAlpha(theme.bgBase(), 0.92f));
        shell.content(scroll);
        applySnapshot();
        return shell;
    }

    private Card fpsCard() {
        Card card = new Card(Lang.tr("vanta.perf.fps"));
        card.setId("perf.fps");
        card.body().gap(Theme.SPACE_3);
        fpsReadout = card.add(new FpsReadout());
        sparkline = card.add(new Sparkline());
        sparkline.height(28);
        target = card.add(new LabelValueRow(Lang.tr("vanta.perf.target_label"), ""));
        return card;
    }

    private Card frameTimeCard() {
        Card card = new Card(Lang.tr("vanta.perf.frame_time"));
        card.setId("perf.frameTime");
        card.body().gap(Theme.SPACE_2);
        frameAvg = card.add(new LabelValueRow(Lang.tr("vanta.perf.average"), ""));
        frameLow = card.add(new LabelValueRow(SettingFormats.text("vanta.perf.one_percent_low"), ""));
        frameMax = card.add(new LabelValueRow(Lang.tr("vanta.perf.max_frame_time"), ""));
        return card;
    }

    private Card memoryCard() {
        Card card = new Card(Lang.tr("vanta.perf.memory"));
        card.setId("perf.memory");
        card.body().gap(Theme.SPACE_2);
        memoryBar = card.add(new MemoryBar());
        memoryUsed = card.add(new LabelValueRow(Lang.tr("vanta.perf.memory_used"), ""));
        memoryAllocated = card.add(new LabelValueRow(Lang.tr("vanta.perf.memory_allocated"), ""));
        memoryMax = card.add(new LabelValueRow(Lang.tr("vanta.perf.memory_max"), ""));
        return card;
    }

    private Card distanceCard() {
        Card card = new Card(Lang.tr("vanta.perf.distances"));
        card.setId("perf.distances");
        card.body().gap(0);
        card.add(row(VantaSettings.VIDEO_RENDER_DISTANCE, false).compact(true));
        card.add(row(VantaSettings.VIDEO_SIMULATION_DISTANCE, true).compact(true));
        entities = card.add(new LabelValueRow(Lang.tr("vanta.perf.entities"), ""));
        return card;
    }

    private Card systemCard() {
        Card card = new Card(Lang.tr("vanta.perf.system"));
        card.setId("perf.system");
        card.body().gap(Theme.SPACE_2);
        cpu = card.add(new LabelValueRow(Lang.tr("vanta.perf.cpu"), ""));
        card.add(new LabelValueRow(Lang.tr("vanta.perf.java"), system.javaVersion()));
        card.add(new LabelValueRow(Lang.tr("vanta.perf.os"), system.osName() + " " + system.osVersion()));
        card.add(new LabelValueRow(Lang.tr("vanta.perf.cpu_threads"), Lang.tr("vanta.perf.threads", system.cpuCount())));
        return card;
    }

    /**
     * Smart Boost: the last result in plain words (or the measurement's progress), the two toggles, Re-tune and Undo,
     * the options the player took over and what the starting guess is based on.
     */
    private Card smartBoostCard() {
        Card card = new Card(Lang.tr("vanta.perf.smart_boost.title")).caption(Lang.tr("vanta.perf.smart_boost.caption"));
        card.setId("perf.smartBoost");
        card.body().gap(Theme.SPACE_2);
        smartStatus = card.add(new Label("", Label.Variant.BODY).wrap(true));
        smartStatus.setId("perf.smartBoost.status");
        smartCappedNote = card.add(new Label(Lang.tr("vanta.perf.smart_boost.capped_note"), Label.Variant.MUTED)
                .wrap(true));
        smartReleased = card.add(new Label("", Label.Variant.MUTED).wrap(true));
        smartReleased.setId("perf.smartBoost.released");
        smartHardware = card.add(new Label("", Label.Variant.CAPTION).wrap(true));
        smartHardware.setId("perf.smartBoost.hardware");
        Column toggles = new Column(0);
        toggles.add(smartRow(VantaSettings.PERFORMANCE_SMART_BOOST, false));
        toggles.add(smartRow(VantaSettings.PERFORMANCE_SMART_BOOST_ADAPTIVE, true));
        card.add(toggles);
        Row buttons = new Row(Theme.SPACE_3).align(Align.CENTER);
        smartRetune = buttons.add(Button.primary(Lang.tr("vanta.perf.smart_boost.retune"), this::smartBoostRetune));
        smartRetune.icon(Icons.ARROW_UP);
        smartRetune.setId("perf.smartBoost.retune");
        smartUndo = buttons.add(Button.ghost(Lang.tr("vanta.perf.smart_boost.undo"), this::smartBoostUndo));
        smartUndo.setId("perf.smartBoost.undo");
        card.add(buttons);
        refreshSmartBoost();
        return card;
    }

    private SettingRow smartRow(Setting<?> setting, boolean last) {
        SettingRow row = new SettingRow(setting, services().settings(), id -> actions().dispatch(context(), id));
        row.last(last);
        row.onChanged(this::refreshSmartBoost);
        smartRows.add(row);
        return row;
    }

    /** Smart Boost's two toggle rows. */
    public List<SettingRow> smartBoostRows() {
        return List.copyOf(smartRows);
    }

    /** Arms a Smart Boost run (it starts with the next gameplay frames). */
    public void smartBoostRetune() {
        services().runAction(ActionEntry.SMART_BOOST_RETUNE);
        refreshSmartBoost();
    }

    /** Restores the video options from before Smart Boost. */
    public void smartBoostUndo() {
        services().runAction(ActionEntry.SMART_BOOST_UNDO);
        onSettingsChanged();
        refreshSmartBoost();
    }

    private void refreshSmartBoost() {
        if (smartStatus == null) {
            return;
        }
        SmartBoostTuner tuner = services().smartBoost();
        SmartBoostState state = tuner.state();
        String status;
        if (tuner.isRunning()) {
            status = tuner.isGated() ? Lang.tr("vanta.perf.smart_boost.status.paused")
                    : Lang.tr("vanta.perf.smart_boost.status.measuring",
                    tuner.measuringPreset().map(p -> Lang.tr(p.langKey())).orElse(""),
                    tuner.measuredMs() / 1000, tuner.windowMs() / 1000);
        } else if (tuner.isPending()) {
            status = Lang.tr("vanta.perf.smart_boost.status.waiting");
        } else if (state.graphicsPresetChosen()) {
            status = Lang.tr("vanta.perf.smart_boost.status.graphics_chosen");
        } else if (state.result().isPresent()) {
            SmartBoostState.Result r = state.result().get();
            status = Lang.tr("vanta.perf.smart_boost.status.last", Lang.tr(r.preset().langKey()),
                    Math.round(r.p50Fps()), r.targetFps(), date(state.lastRunAtMillis()));
        } else {
            status = Lang.tr("vanta.perf.smart_boost.status.never");
        }
        List<String> released = new ArrayList<>();
        for (VanillaOption option : tuner.releasedOptions()) {
            released.add(Lang.tr(option.langKey()));
        }
        String releasedText = released.isEmpty() ? ""
                : Lang.tr("vanta.perf.smart_boost.released", String.join(", ", released));
        String gpu = services().game().gpuRenderer().filter(g -> !g.isBlank())
                .orElse(Lang.tr("vanta.perf.smart_boost.hardware.no_gpu"));
        String hardware = Lang.tr("vanta.perf.smart_boost.hardware", system.cpuCount(),
                String.format(Locale.ROOT, "%.1f", system.maxHeapBytes() / (double) (1L << 30)), gpu);
        boolean capped = perf.isFpsCapped();
        boolean canUndo = tuner.canUndo();
        String signature = status + "|" + releasedText + "|" + hardware + "|" + capped + "|" + canUndo;
        if (signature.equals(smartSignature)) {
            return;
        }
        smartSignature = signature;
        smartStatus.setText(status);
        smartReleased.setText(releasedText);
        smartReleased.setVisible(!releasedText.isEmpty());
        smartHardware.setText(hardware);
        smartCappedNote.setVisible(capped);
        smartUndo.setEnabled(canUndo);
        invalidateLayout();
    }

    private static String date(long epochMillis) {
        if (epochMillis <= 0) {
            return "";
        }
        return DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ROOT)
                .format(Instant.ofEpochMilli(epochMillis).atZone(ZoneId.systemDefault()));
    }

    private Card presetCard() {
        Card card = new Card(Lang.tr("vanta.perf.presets")).caption(Lang.tr("vanta.perf.preset_hint"));
        card.setId("perf.presets");
        currentPreset = new Badge("", Badge.Tone.ACCENT);
        card.headerSlot(currentPreset);
        Row boost = new Row(Theme.SPACE_4).align(Align.CENTER);
        boostFps = Button.primary(Lang.tr("vanta.action." + ActionEntry.BOOST_FPS), this::boostFps);
        boostFps.icon(Icons.ARROW_UP);
        boostFps.setId("perf.boostFps");
        boost.add(boostFps);
        Label boostHint = new Label(Lang.tr("vanta.action." + ActionEntry.BOOST_FPS + ".description"),
                Label.Variant.MUTED).wrap(true);
        boostHint.flex(1f);
        boost.add(boostHint);
        card.add(boost);
        List<String> labels = new ArrayList<>();
        for (PerformancePreset preset : PerformancePreset.values()) {
            labels.add(Lang.tr(preset.langKey()));
        }
        presetTabs = card.add(new Tabs(labels, selectedPreset.ordinal()));
        presetTabs.setId("perf.presetTabs");
        presetTabs.onSelect(i -> selectPreset(PerformancePreset.values()[i]));
        presetDescription = card.add(new Label("", Label.Variant.CAPTION).wrap(true));
        diffTable = card.add(new PresetDiffTable(selectedDiff()));
        Row footer = new Row(Theme.SPACE_3);
        diffSummary = footer.add(new Label("", Label.Variant.MUTED));
        footer.add(Spacer.grow());
        applyPreset = footer.add(Button.primary(Lang.tr("vanta.perf.apply"), this::applySelectedPreset));
        applyPreset.icon(Icons.CHECK);
        applyPreset.setId("perf.applyPreset");
        card.add(footer);
        refreshPreset();
        return card;
    }

    private Card quickOptionsCard() {
        Card card = new Card(Lang.tr("vanta.perf.quick_options")).caption(Lang.tr("vanta.perf.quick_options.description"));
        card.setId("perf.quick");
        card.body().gap(0);
        for (int i = 0; i < QUICK_OPTIONS.size(); i++) {
            card.add(row(QUICK_OPTIONS.get(i), i == QUICK_OPTIONS.size() - 1));
        }
        return card;
    }

    private SettingRow row(Setting<?> setting, boolean last) {
        SettingRow row = new SettingRow(setting, services().settings(), id -> actions().dispatch(context(), id));
        row.last(last);
        row.onChanged(this::refreshPreset);
        rows.add(row);
        return row;
    }

    @Override
    protected void onScreenInit() {
        services().settings().addListener(externalChange);
    }

    @Override
    protected void onScreenClose() {
        services().settings().removeListener(externalChange);
    }

    private void onSettingsChanged() {
        for (SettingRow row : rows) {
            row.refresh();
        }
        for (SettingRow row : smartRows) {
            row.refresh();
        }
        refreshPreset();
        refreshSmartBoost();
    }

    // ---------------------------------------------------------------- presets

    /** Shows the diff of a preset without applying it. */
    public void selectPreset(PerformancePreset preset) {
        selectedPreset = preset;
        if (presetTabs != null && presetTabs.selected() != preset.ordinal()) {
            presetTabs.select(context(), preset.ordinal());
        }
        refreshPreset();
    }

    /** Applies the selected preset (vanilla options only) and refreshes every row. */
    public void applySelectedPreset() {
        perf.applyPreset(selectedPreset);
        onSettingsChanged();
    }

    /** Runs the one-click FPS boost (see {@link VantaServices#boostFps()}) and shows BOOST in the tabs. */
    public void boostFps() {
        services().boostFps();
        selectPreset(PerformancePreset.BOOST);
        onSettingsChanged();
        refreshBoostButton();
    }

    private void refreshPreset() {
        if (diffTable == null) {
            return;
        }
        PresetDiff diff = selectedDiff();
        diffTable.setDiff(diff);
        presetDescription.setText(Lang.tr(selectedPreset.descriptionKey()));
        int changes = diff.changeCount();
        diffSummary.setText(changes == 0 ? Lang.tr("vanta.perf.diff.no_changes")
                : Lang.tr("vanta.perf.diff.changes", changes));
        applyPreset.setEnabled(changes > 0);
        Optional<PerformancePreset> active = perf.detectPreset();
        currentPreset.setText(Lang.tr("vanta.perf.current_preset",
                active.map(p -> Lang.tr(p.langKey())).orElse(Lang.tr("vanta.perf.custom"))));
        invalidateLayout();
    }

    // ---------------------------------------------------------------- suggestion

    private void acceptSuggestion() {
        perf.acceptSuggestion();
        onSettingsChanged();
        snapshot = perf.snapshot();
        applySnapshot();
    }

    private void dismissSuggestion() {
        perf.dismissSuggestion();
        snapshot = perf.snapshot();
        applySnapshot();
    }

    // ---------------------------------------------------------------- live data

    @Override
    protected void onScreenTick() {
        if (game.isInWorld()) {
            pushFps(game.fps());
        }
        snapshot = perf.snapshot();
        applySnapshot();
        refreshBoostButton();
        refreshSmartBoost();
    }

    /** The Boost button waits while its Performance pack install is still running (a second click queues nothing). */
    private void refreshBoostButton() {
        if (boostFps == null) {
            return;
        }
        boolean busy = services().modrinth().map(ModrinthService::isBusy).orElse(false);
        if (boostFps.isEnabled() == busy) {
            boostFps.setEnabled(!busy);
            invalidateLayout();
        }
    }

    private void applySnapshot() {
        if (sparkline == null) {
            return;
        }
        boolean inWorld = game.isInWorld();
        boolean layoutChanged = noWorldBanner.isVisible() == inWorld;
        noWorldBanner.setVisible(!inWorld);
        sparkline.setValues(fpsHistory()).reference(perf.isFpsCapped() ? (float) perf.targetFps() : null);
        fpsReadout.set(inWorld ? snapshot.fps() : -1, snapshot.onePercentLowFps());
        target.setValue(perf.isFpsCapped() ? Lang.tr("vanta.common.fps", perf.targetFps())
                : Lang.tr("vanta.common.unlimited"));
        frameAvg.setValue(ms(snapshot.frameTimeAvgMs()));
        frameLow.setValue(snapshot.frameTimeOnePercentMs() > 0
                ? ms(snapshot.frameTimeOnePercentMs()) + " · " + Lang.tr("vanta.common.fps", Math.round(snapshot.onePercentLowFps()))
                : ms(0));
        frameMax.setValue(ms(snapshot.frameTimeMaxMs()));
        MemorySampler.MemorySample mem = snapshot.memory();
        memoryBar.set(mem);
        memoryUsed.setValue(mb(mem.used()) + "  (" + Math.round(mem.usedFraction() * 100) + " %)");
        memoryAllocated.setValue(mb(mem.allocated()));
        memoryMax.setValue(mb(mem.max()));
        entities.setValue(inWorld ? Integer.toString(snapshot.entityCount()) : Lang.tr("vanta.common.not_available"));
        cpu.setValue(snapshot.cpuLoad().isPresent()
                ? Lang.tr("vanta.perf.cpu_value", Math.round(snapshot.cpuLoad().getAsDouble() * 100))
                : Lang.tr("vanta.perf.cpu_unavailable"));
        Optional<RenderDistanceAdvisor.Suggestion> suggestion = snapshot.suggestion();
        boolean hadSuggestion = suggestionBanner.isVisible();
        suggestionBanner.setVisible(suggestion.isPresent());
        if (suggestion.isPresent()) {
            RenderDistanceAdvisor.Suggestion s = suggestion.get();
            String key = s.direction() == RenderDistanceAdvisor.Direction.LOWER ? "vanta.perf.suggestion.lower"
                    : "vanta.perf.suggestion.higher";
            suggestionBanner.setTitle(Lang.tr(key, s.to()));
            suggestionBanner.setBody(Lang.tr("vanta.perf.suggestion.reason", Math.round(s.averageFps()), s.targetFps()));
        }
        if (layoutChanged || hadSuggestion != suggestion.isPresent()) {
            invalidateLayout();
        }
    }

    private static String ms(double value) {
        return Lang.tr("vanta.perf.frame_time_value", String.format(Locale.ROOT, "%.1f", value));
    }

    private static String mb(long bytes) {
        return Lang.tr("vanta.perf.mb", MemorySampler.MemorySample.toMiB(bytes));
    }

    // ---------------------------------------------------------------- nodes

    /** Big frame rate number with the 1 % low beside it. */
    private static final class FpsReadout extends UiNode {
        private int fps = -1;
        private double low;

        void set(int fpsValue, double onePercentLow) {
            this.fps = fpsValue;
            this.low = onePercentLow;
        }

        @Override
        protected Size measure(UiContext ctx) {
            return new Size(120, 18);
        }

        @Override
        protected void renderSelf(Canvas canvas, UiContext ctx) {
            Theme theme = ctx.theme();
            Rect b = bounds();
            String big = fps < 0 ? "—" : Integer.toString(fps);
            canvas.text(big, b.x(), b.y() + (b.h() - canvas.lineHeight(FontKind.DISPLAY)) / 2, theme.textPrimary(),
                    FontKind.DISPLAY, false);
            int x = b.x() + canvas.textWidth(big, FontKind.DISPLAY) + Theme.SPACE_2;
            int ty = b.y() + (b.h() - canvas.lineHeight(FontKind.UI)) / 2 + 2;
            canvas.text(Lang.tr("vanta.perf.fps"), x, ty, theme.textMuted(), FontKind.UI, false);
            if (low > 0) {
                String lowText = SettingFormats.text("vanta.perf.one_percent_low") + " " + Math.round(low);
                canvas.textRight(canvas.textClipped(lowText, b.w() / 2, FontKind.UI), b.right(), ty, theme.textSecondary(),
                        FontKind.UI, false);
            }
        }
    }

    /** Stacked bar: used heap over the allocated heap over the maximum heap. */
    private static final class MemoryBar extends UiNode {
        private MemorySampler.MemorySample sample = new MemorySampler.MemorySample(0, 0, 1);

        void set(MemorySampler.MemorySample s) {
            this.sample = s;
        }

        @Override
        protected Size measure(UiContext ctx) {
            return new Size(120, 8);
        }

        @Override
        protected void renderSelf(Canvas canvas, UiContext ctx) {
            Theme theme = ctx.theme();
            Rect b = bounds();
            int h = Math.min(6, b.h());
            int y = b.y() + (b.h() - h) / 2;
            canvas.fillRounded(b.x(), y, b.w(), h, Theme.RADIUS_SM, theme.surface3());
            long max = Math.max(1, sample.max());
            int allocated = (int) Math.round(b.w() * Math.min(1.0, sample.allocated() / (double) max));
            int used = (int) Math.round(b.w() * Math.min(1.0, sample.used() / (double) max));
            if (allocated > 0) {
                canvas.fillRounded(b.x(), y, allocated, h, Theme.RADIUS_SM, theme.surface4());
            }
            if (used > 0) {
                double fraction = sample.usedFraction();
                int end = fraction > 0.9 ? theme.danger() : fraction > 0.75 ? theme.warning() : theme.gradientEnd();
                canvas.fillRoundedGradientH(b.x(), y, used, h, Theme.RADIUS_SM, theme.gradientStart(), end);
            }
        }
    }
}
